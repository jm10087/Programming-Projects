﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class NullPages_LecturerNull : System.Web.UI.Page
{
    Lecturer lecturer;
    String module;
    String room;
    String staffId;
    String day;
    String time;
    int semester;
    List<TableRow> tablerowList = new List<TableRow>();
    List<String> moduleID = new List<String>();
    int tableid = 0;
    List<String> moduleIDNew = new List<string>();
    String test;
    String dayString;
    String timeString;
    List<String> staffIdList = new List<string>();
    List<String> lectureID = new List<string>();
    List<int> semesterList = new List<int>();
    List<String> dayList = new List<String>();
    List<String> timeList = new List<String>();
    List<String> LecturerID = new List<string>();
    int tableid2 = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            readLecturer();

            //Populates dropdown box with list of lecture ids
            DropDownListLecturer.DataSource = LecturerID;
            DropDownListLecturer.DataBind();
            DropDownListLecturer.SelectedIndex = 0;
            //DropDownListLecturer.AutoPostBack = true;
        }

        displayNulls();
    }

    //Displays a list of null lectures
    protected void displayNulls()
    {
        try
        {

        moduleID.Clear();
        lectureID.Clear();

        lecturer = new Lecturer();
        lecturer.readLecturerNull(); //Selects lectures that are unassigned to staff
        int j = lecturer.countLectureIdList(); //Amount of unassigned lectures

        for (int i = 0; i < j; i++)
        {
            lectureID.Add(lecturer.getLectureIdList(i)); //Adds unassigned lectures to array
        }

        //Clear table rows
        Table1.Rows.Clear();

        //Creates header rows
        TableHeaderRow theadRow = new TableHeaderRow();

        TableHeaderCell theadCellYear = new TableHeaderCell();
        theadCellYear.Text = "Year";
        TableHeaderCell theadCellModule = new TableHeaderCell();
        theadCellModule.Text = "Module";
        TableHeaderCell theadCellSemester = new TableHeaderCell();
        theadCellSemester.Text = "Semester";
        TableHeaderCell theadCellWeek = new TableHeaderCell();
        theadCellWeek.Text = "Week";
        TableHeaderCell theadCellDay = new TableHeaderCell();
        theadCellDay.HorizontalAlign = HorizontalAlign.Center;
        theadCellDay.Text = "Day";
        TableHeaderCell theadCellTime = new TableHeaderCell();
        theadCellTime.HorizontalAlign = HorizontalAlign.Center;
        theadCellTime.Text = "Time";

        theadRow.Cells.Add(theadCellYear);
        theadRow.Cells.Add(theadCellModule);
        theadRow.Cells.Add(theadCellSemester);
        theadRow.Cells.Add(theadCellWeek);
        theadRow.Cells.Add(theadCellDay);
        theadRow.Cells.Add(theadCellTime);

        Table1.Rows.Add(theadRow);

        for (int i = 0; i < j; i++)
        {
            //Selects day, time, week and semester of each lecture in the loop
            lecturer.readLecturerFinal2(lectureID[i]);

            module = lecturer.getModule();
            semester = lecturer.getSemester();
            day = lecturer.getDay();
            //setDay(day);
            time = lecturer.getTime();
            String week = lecturer.getWeek();
            //setTime(time);

            //Reads the year of the selected module
            //ModuleIds frequently contain excess information after a '/'
            if (module.Contains("/"))
            {
                String module2 = module.Substring(0, module.IndexOf("/"));
                lecturer.readYearFromModule(module2);
            }
            else
            {
                lecturer.readYearFromModule(module);
            }

            String yearId = lecturer.getYear();

            //Creates table rows
            TableRow tablerow = new TableRow();
            tablerow.ID = "tablerow" + tableid.ToString();

            TableCell tablecellYear = new TableCell();
            tablecellYear.Text = yearId;

            TableCell tablecellModuleId = new TableCell();
            tablecellModuleId.Text = module;

            TableCell tablecellSemesterId = new TableCell();
            tablecellSemesterId.Text = semester.ToString();
            tablecellSemesterId.HorizontalAlign = HorizontalAlign.Center;

            TableCell tableCellWeek = new TableCell();
            tableCellWeek.Text = week;
            tableCellWeek.HorizontalAlign = HorizontalAlign.Center;

            TableCell tablecellDay = new TableCell();
            tablecellDay.Text = day;

            TableCell tablecellTime = new TableCell();
            tablecellTime.Text = time;

            tablerow.Cells.Add(tablecellYear);
            tablerow.Cells.Add(tablecellModuleId);
            tablerow.Cells.Add(tablecellSemesterId);
            tablerow.Cells.Add(tableCellWeek);
            tablerow.Cells.Add(tablecellDay);
            tablerow.Cells.Add(tablecellTime);

            lecturer.readFromLecturerTable();
            List<String> staffId = new List<string>();

            for (int t = 0; t < lecturer.getStaffIdCount(); t++)
            {
                staffId.Add(lecturer.getLecturerIdList(t));
            }

            //DropDownList test = new DropDownList();
            //test.DataSource = staffId;
            //test.DataBind();
            //test.AutoPostBack = true;

            //TableCell tbDropDown = new TableCell();
            //tbDropDown.Controls.Add(test);

            //Creates button to assign lecturer to lectureId
            Button button = new Button();
            button.ID = "buttonleft" + i.ToString();
            button.Attributes.Add("runat", "server");
            button.Text = "Assign Lecturer";
            button.CommandArgument = lectureID[i] + "^" + DropDownListLecturer .SelectedValue;
            button.Command += new CommandEventHandler(firstButton);

            TableCell tablecellButton = new TableCell();
            tablecellButton.Controls.Add(button);

            //Button to delete lecture
            Button buttonRemove = new Button();
            buttonRemove.ID = "buttonright" + i.ToString();
            buttonRemove.Attributes.Add("runat", "server");
            buttonRemove.Text = "Remove";
            buttonRemove.CommandArgument = lectureID[i];
            buttonRemove.Command += new CommandEventHandler(secondButton);

            TableCell tablecellButton2 = new TableCell();
            tablecellButton2.Controls.Add(buttonRemove);

            //tablerow.Cells.Add(tbDropDown);
            tablerow.Cells.Add(tablecellButton);
            tablerow.Cells.Add(tablecellButton2);

            Table1.Rows.Add(tablerow);

            tableid++;

        }
        }
        catch (Exception ex)
        {
          //lblError.Text = "Please enter a valid semester or staff number.";
        }
    }

    //Assigns the selected lectureId the value in the dropdownbox
    protected void firstButton(object sender, CommandEventArgs e)
    {
        lecturer = new Lecturer();

        //Splits into lectureId and dropdownbox value
        char[] delimiterChars = { '^'};
        String s = e.CommandArgument.ToString();

        String[] t = s.Split(delimiterChars);

        lecturer.writeLectureById(t[0], t[1]); //Writes lecturer to lectureId
        displayNulls(); //Loads table after logic has been completed
    }
    
    //Deletes lecture from Lecture table
    protected void secondButton(object sender, CommandEventArgs e)
    {
        lecturer = new Lecturer();
        String s = e.CommandArgument.ToString();
        lecturer.deleteEntry(s); //Deletes the selected lecture from the Lecture table
        displayNulls(); //Loads table after logic has been completed
    }

    
    //This is old code
    protected void setDay(int a)
    {
        switch (a)
        {
            case 0:
                dayString = "Not set";
                break;

            case 1:
                dayString = "Monday";
                break;

            case 2:
                dayString = "Tuesday";
                break;

            case 3:
                dayString = "Wednesday";
                break;

            case 4:
                dayString = "Thursday";
                break;

            case 5:
                dayString = "Friday";
                break;

            case 6:
                dayString = "Saturday";
                break;

            case 7:
                dayString = "Sunday";
                break;
        }
    }

    //This is old code
    protected void setTime(int a)
    {
        switch (a)
        {

            case 0:
                timeString = "Not set";
                break;

            case 1:
                timeString = "8:00 - 9:00";
                break;

            case 2:
                timeString = "9:00 - 10:00";
                break;

            case 3:
                timeString = "10:00 - 11:00";
                break;

            case 4:
                timeString = "11:00- 12:00";
                break;

            case 5:
                timeString = "12:00 - 13:00";
                break;

            case 6:
                timeString = "13:00 - 14:00";
                break;

            case 7:
                timeString = "14:00 - 15:00";
                break;

            case 8:
                timeString = "15:00 - 16:00";
                break;

            case 9:
                timeString = "16:00 - 17:00";
                break;

            case 10:
                timeString = "17:00 - 18:00";
                break;

            case 11:
                timeString = "18:00 - 19:00";
                break;
        }
    }





    

    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/MainMenu.aspx");
    }
    protected void btnBack_Click1(object sender, EventArgs e)
    {
        Response.Redirect("~/MainMenu.aspx");
    }

    //Reads a list of lecturers and adds them to an array. This will be used to populate the dropdown box.
    protected void readLecturer()
    {
        lecturer = new Lecturer();
        lecturer.readFromLecturerTable();
        int k = lecturer.getStaffIdCount();

        for (int i = 0; i < k; i++)
        {
            LecturerID.Add(lecturer.getLecturerIdList(i));
        }
    }
   
}