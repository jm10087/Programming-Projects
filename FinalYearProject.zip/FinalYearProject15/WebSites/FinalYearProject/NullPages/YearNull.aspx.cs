﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class NullPages_YearNull : System.Web.UI.Page
{
    Year year;
    String module;
    String room;
    String staffId;
    String day;
    String time;
    int semester;
    List<TableRow> tablerowList = new List<TableRow>();
    List<String> moduleID = new List<String>();
    int tableid = 0;
    List<String> moduleIDNew = new List<string>();
    String test;
    String dayString;
    String timeString;
    List<String> staffIdList = new List<string>();
    List<String> lectureID = new List<string>();
    List<int> semesterList = new List<int>();
    List<String> dayList = new List<String>();
    List<String> timeList = new List<String>();
    int tableid2 = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        //Adds semesters, days and times to dropdown lists
        if (!Page.IsPostBack)
        {
            semesterList.Add(1);
            semesterList.Add(2);
            DropDownSemester.DataSource = semesterList;
            DropDownSemester.DataBind();
            DropDownSemester.SelectedIndex = 0;
            DropDownSemester.AutoPostBack = true;

            dayList.Add("Monday");
            dayList.Add("Tuesday");
            dayList.Add("Wednesday");
            dayList.Add("Thursday");
            dayList.Add("Friday");
            DropDownDay.DataSource = dayList;
            DropDownDay.DataBind();
            DropDownDay.SelectedIndex = 0;
            DropDownDay.AutoPostBack = true;
           

            timeList.Add("8:00 - 9:00");
            timeList.Add("9:00 - 10:00");
            timeList.Add("10:00 - 11:00");
            timeList.Add("11:00 - 12:00");
            timeList.Add("12:00 - 13:00");
            timeList.Add("13:00 - 14:00");
            timeList.Add("14:00 - 15:00");
            timeList.Add("15:00 - 16:00");
            timeList.Add("16:00 - 17:00");
            timeList.Add("17:00 - 18:00");
            timeList.Add("18:00 - 19:00");
            DropDownTime.DataSource = timeList;
            DropDownTime.DataBind();
            DropDownTime.SelectedIndex = 0;
            DropDownTime.AutoPostBack = true;
        }

        displayNulls();
    }

    //Displays a list of null lectures
    protected void displayNulls()
    {
        try
        {

        moduleID.Clear();
        lectureID.Clear();

        year = new Year();
        year.readYearNull(); //Selects lectures that have no time assigned
        int j = year.countLectureIdList(); //Amount of unassigned lectures

        for (int i = 0; i < j; i++)
        {
            lectureID.Add(year.getLectureIdList(i)); //Adds unassigned lectures to array
        }

        //Clear table rows
        Table1.Rows.Clear();

        //Creates header rows
        TableHeaderRow theadRow = new TableHeaderRow();

        TableHeaderCell theadCellYear = new TableHeaderCell();
        theadCellYear.Text = "Year";

        TableHeaderCell theadCellModule = new TableHeaderCell();
        theadCellModule.Text = "Module";

        theadRow.Cells.Add(theadCellYear);
        theadRow.Cells.Add(theadCellModule);

        Table1.Rows.Add(theadRow);

        for (int i = 0; i < j; i++)
        {
            //Selects day, time, week and semester of each lecture in the loop
            year.readYearFinal2(lectureID[i]);

            module = year.getModule().Trim();
            semester = year.getSemester();
            day = year.getDay();
            //setDay(day);
            time = year.getTime();
            //setTime(time);
            String week = year.getWeek();

            //Reads the year of the selected module
            //ModuleIds frequently contain excess information after a '/
            if (module.Contains("/"))
            {
                String module2 = module.Substring(0, module.IndexOf("/"));
                year.readYearFromModule(module2);
            }
            else
            {
                year.readYearFromModule(module);
            }

            String yearId = year.getYear();

            //Creates table rows
            TableRow tablerow = new TableRow();
            tablerow.ID = "tablerow" + tableid.ToString();

            TableCell tablecellYear = new TableCell();
            tablecellYear.Text = yearId;

            TableCell tablecellModuleId = new TableCell();
            tablecellModuleId.Text = module;

            TableCell tablecellSemesterId = new TableCell();
            if (semester != 0)
            {
                tablecellSemesterId.Text = semester.ToString();
            }
            else
            {
                tablecellSemesterId.Text = "Not set";
            }
            
            tablecellSemesterId.HorizontalAlign = HorizontalAlign.Center;

            TableCell tableCellWeek = new TableCell();
            tableCellWeek.HorizontalAlign = HorizontalAlign.Center;
            tableCellWeek.Text = week;

            TableCell tablecellDay = new TableCell();
            tablecellDay.HorizontalAlign = HorizontalAlign.Center;
            tablecellDay.Text = day;

            TableCell tablecellTime = new TableCell();
            tablecellTime.HorizontalAlign = HorizontalAlign.Center;
            tablecellTime.Text = time;

            tablerow.Cells.Add(tablecellYear);
            tablerow.Cells.Add(tablecellModuleId);
            //tablerow.Cells.Add(tablecellSemesterId);
            //tablerow.Cells.Add(tablecellDay);
            //tablerow.Cells.Add(tablecellTime);


            //Creates button to schedule a lectureId
            Button button = new Button();
            button.ID = "buttonleft" + i.ToString();
            button.Attributes.Add("runat", "server");
            button.Text = "Assign Time";
            button.CommandArgument = lectureID[i];
            button.Command += new CommandEventHandler(firstButton);

            TableCell tablecellButton = new TableCell();
            tablecellButton.Controls.Add(button);

            //Button to delete lecture
            Button buttonRight = new Button();
            buttonRight.ID = "buttonright" + i.ToString();
            buttonRight.Attributes.Add("runat", "server");
            buttonRight.Text = "Remove";
            buttonRight.CommandArgument = lectureID[i];
            buttonRight.Command += new CommandEventHandler(secondButton);

            TableCell tablecellButton2 = new TableCell();
            tablecellButton2.Controls.Add(buttonRight);

            tablerow.Cells.Add(tablecellButton);
            tablerow.Cells.Add(tablecellButton2);

            Table1.Rows.Add(tablerow);

            tableid++;

        }
        }
        catch (Exception ex)
        {
          //lblError.Text = "Please enter a valid semester or staff number.";
        }
    }

    //Schedules the selected lectureId the time, day, week and semester specified in the dropdownboxes/textbox
    protected void firstButton(object sender, CommandEventArgs e)
    {
        if (txtWeek.Text != "")
        {
            year = new Year();
            String s = e.CommandArgument.ToString();

            int semesterArg = Convert.ToInt32(DropDownSemester.SelectedValue);
            String weekArg = txtWeek.Text;
            String dayArg = DropDownDay.SelectedValue;
            String timeArg = DropDownTime.SelectedValue;
            //Label1.Text = "";
            year.writeLectureNull(s, weekArg, dayArg, timeArg, semesterArg); //Schedules lectureId
            displayNulls(); //Loads table after logic has been completed
        }
        else
        {
            //Label1.Text = "You must enter a week";
        }
    }

    //This is old code
    protected void setDay(int a)
    {
        switch (a)
        {
            case 0:
                dayString = "Not set";
                break;

            case 1:
                dayString = "Monday";
                break;

            case 2:
                dayString = "Tuesday";
                break;

            case 3:
                dayString = "Wednesday";
                break;

            case 4:
                dayString = "Thursday";
                break;

            case 5:
                dayString = "Friday";
                break;

            case 6:
                dayString = "Saturday";
                break;

            case 7:
                dayString = "Sunday";
                break;
        }
    }

    //This is old code
    protected void setTime(int a)
    {
        switch (a)
        {
            case 0:
                timeString = "Not set";
                break;

            case 1:
                timeString = "8:00 - 9:00";
                break;

            case 2:
                timeString = "9:00 - 10:00";
                break;

            case 3:
                timeString = "10:00 - 11:00";
                break;

            case 4:
                timeString = "11:00- 12:00";
                break;

            case 5:
                timeString = "12:00 - 13:00";
                break;

            case 6:
                timeString = "13:00 - 14:00";
                break;

            case 7:
                timeString = "14:00 - 15:00";
                break;

            case 8:
                timeString = "15:00 - 16:00";
                break;

            case 9:
                timeString = "16:00 - 17:00";
                break;

            case 10:
                timeString = "17:00 - 18:00";
                break;

            case 11:
                timeString = "18:00 - 19:00";
                break;
        }
    }

    //This is old code
    protected int saveDay(String day)
    {
        if (day == "Monday")
        {
            return 1;
        }
        else if (day == "Tuesday")
        {
            return 2;
        }
        else if (day == "Wednesday")
        {
            return 3;
        }

        else if (day == "Thursday")
        {
            return 4;
        }

        else if (day == "Friday")
        {
            return 5;
        }

        else
        {
            return 0;
        }
    }

    //This is old code
    public int saveTime(String time)
    {
        if (time == "8:00 - 9:00")
        {
            return 1;
        }

        else if (time == "9:00 - 10:00")
        {
            return 2;
        }

        else if (time == "10:00 - 11:00")
        {
            return 3;
        }

        else if (time == "11:00 - 12:00")
        {
            return 4;
        }

        else if (time == "12:00 - 13:00")
        {
            return 5;
        }

        else if (time == "13:00 - 14:00")
        {
            return 6;
        }

        else if (time == "14:00 - 15:00")
        {
            return 7;
        }

        else if (time == "15:00 - 16:00")
        {
            return 8;
        }

        else if (time == "16:00 - 17:00")
        {
            return 9;
        }

        else if (time == "17:00 - 18:00")
        {
            return 10;
        }

        else if (time == "18:00 - 19:00")
        {
            return 11;
        }

        else
        {
            return 0;
        }
    }


    //This is old code
    protected void Button1_Click(object sender, EventArgs e)
    {
        //displayClashes();
    }

    //Deletes lecture from Lecture table
    public void secondButton(object sender, CommandEventArgs e)
    {
        
            year = new Year();
            String s = e.CommandArgument.ToString();
            year.deleteEntry(s); //Deletes the selected lecture from the Lecture table
            displayNulls(); //Loads table after logic has been completed
      
    }



    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/MainMenu.aspx");
    }
    
}