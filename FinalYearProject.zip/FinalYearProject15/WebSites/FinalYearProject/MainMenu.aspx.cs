﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

//This page is used to navigate to other pages

public partial class MainMenu : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }


    protected void btnLecturer_Click(object sender, EventArgs e)
    {
        Response.Redirect("LecturerTimetable.aspx");
    }
    protected void btnRoom_Click(object sender, EventArgs e)
    {
        Response.Redirect("RoomTimetable.aspx");
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Response.Redirect("default.aspx");
    }
    protected void btnLecturerEdit_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Save/LecturerSave.aspx");
    }
    protected void btnRoomEdit_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Save/RoomSave.aspx");
    }
    protected void btnYearEdit_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Save/YearSave2.aspx");
    }
    protected void btnLecturerClash_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Clashes/LecturerClashes.aspx");
    }
    protected void btnRoomClash_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Clashes/RoomClashes.aspx");
    }
    protected void btnYear_Click(object sender, EventArgs e)
    {
        Response.Redirect("YearTimetable.aspx");
    }
    protected void btnYearClash_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Clashes/YearClashes.aspx");
    }
    protected void btnLecturerNulls_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/NullPages/LecturerNull.aspx");
    }
    protected void btnRoomNulls_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/NullPages/RoomNull.aspx");
    }
    protected void btnYearNulls_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/NullPages/YearNull.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/test.aspx");
    }
}