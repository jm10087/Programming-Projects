﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Save_LecturerSave : System.Web.UI.Page
{

    Lecturer lecturer;
    String module;
    String room;
    String staffId;
    String day;
    String time;
    int semester;
    List <TableRow> tablerowList = new List<TableRow>();
    List<String> moduleID = new List<String>();
    int tableid = 0;
    List <String> moduleIDNew = new List<string>();
    String test;
    String dayString;
    String timeString;
    String lectureId;

    List<String> staffIdList = new List<string>();

    protected void Page_Load(object sender, EventArgs e)
    {

        //Populates dropdown boxes with lecturers (and modules, which can be saved)
        if (!Page.IsPostBack)
        {
            getModule();
            DropDownList1.DataSource = moduleIDNew;
            DropDownList1.DataBind();
            //DropDownList1.AutoPostBack = true;
            DropDownList1.SelectedIndex = 0;

            lecturer = new Lecturer();
            lecturer.readFromLecturerTable();
            int j = lecturer.getStaffIdCount();
            for (int i = 0; i < j; i++)
            {
                staffIdList.Add(lecturer.getLecturerIdList(i));
            }

            DropDownStaff.DataSource = staffIdList;
            DropDownStaff.DataBind();
            DropDownStaff.SelectedIndex = 0;
            //DropDownStaff.AutoPostBack = true;

            DropDownList2.Items.Add("Lecture");
            DropDownList2.Items.Add("Tutorial");
            DropDownList2.DataBind();
            DropDownList2.SelectedIndex = 0;
        }

        //Reloads the dynamically created table on postback
        test = DropDownList1.SelectedValue;

        if (hiddenLecturer.Value != "")
        {
            displayLectures(hiddenLecturer.Value);  
        }
        else
        {
           
        }
    }

    //This creates the lectures of a particular lecturer
    protected void displayLectures(String x)
    {

        try
        {
            
            moduleID.Clear();

            //Makes the controls used to add lectures visible
            DropDownList1.Visible = true;
            DropDownList2.Visible = true;
            lblAdd.Visible = true;
            btnSave.Visible = true;
            
            //Creates table
            Table table = new Table();

            staffId = x;

            lecturer = new Lecturer();
            //Selects lectures belonging to the selected lecturer
            lecturer.readLecturerTestSave(staffId);
            //Selects amount of lectures belonging to a particular lecturer
            int j = lecturer.getModuleCount();

            //Deletes table rows before populating them again
            table1.Rows.Clear();

            //Creates header rows
            TableHeaderRow theadRow = new TableHeaderRow();

            TableHeaderCell theadCellYear = new TableHeaderCell();
            theadCellYear.Text = "Year";
            TableHeaderCell theadCellModule = new TableHeaderCell();
            theadCellModule.Text = "Module";
            TableHeaderCell theadCellSemester = new TableHeaderCell();
            theadCellSemester.Text = "Semester";
            TableHeaderCell theadCellWeek = new TableHeaderCell();
            theadCellWeek.Text = "Week";
            TableHeaderCell theadCellDay = new TableHeaderCell();
            theadCellDay.Text = "Day";
            TableHeaderCell theadCellTime = new TableHeaderCell();
            theadCellTime.Text = "Time";

            theadRow.Cells.Add(theadCellYear);
            theadRow.Cells.Add(theadCellModule);
            theadRow.Cells.Add(theadCellSemester);
            theadRow.Cells.Add(theadCellWeek);
            theadRow.Cells.Add(theadCellDay);
            theadRow.Cells.Add(theadCellTime);

            table1.Rows.Add(theadRow);

            for (int i = 0; i < j; i++)
            {
                //Reads data for each lecture of the selected lecturer
                lecturer.readLecturerSave(staffId, i);

                String week = lecturer.getWeek();
                lectureId = lecturer.getLectureId();
                semester = lecturer.getSemester(); 
                module = lecturer.getModule();
                room = lecturer.getRoom();
                day = lecturer.getDay();
                time = lecturer.getTime();
                moduleID.Add(module);

                //setDay(day);
                //setTime(time);

                //Modules commonly contain excess information after a '/'
                if (module.Contains("/"))
                {
                    String module2 = module.Substring(0, module.IndexOf("/"));
                    lecturer.readYearFromModule(module2);
                }
                else
                {
                    lecturer.readYearFromModule(module);
                }
                //Determines the year of the currently selected module
                String yearId = lecturer.getYear();
             
                //Polulates table based on read data
                if (module != null)
                {

                    TableRow tablerow = new TableRow();
                    tablerow.ID = "tablerow" + tableid.ToString();

                    TableCell tablecellYear = new TableCell();
                    tablecellYear.Text = yearId;

                    tablerow.Cells.Add(tablecellYear);

                    TableCell tablecellModule = new TableCell();
                    tablecellModule.Text = module;

                    tablerow.Cells.Add(tablecellModule);

                    TableCell semesterCell = new TableCell();
                    if (semester != 0)
                    {
                        semesterCell.Text = semester.ToString();
                    }
                    else
                    {
                        semesterCell.Text = "Not set";
                    }
                    semesterCell.HorizontalAlign = HorizontalAlign.Center;
                    tablerow.Cells.Add(semesterCell);

                    TableCell weekCell = new TableCell();
                    weekCell.HorizontalAlign = HorizontalAlign.Center;
                    weekCell.Text = week;
                    tablerow.Cells.Add(weekCell);

                    TableCell dayCell = new TableCell();
                    dayCell.HorizontalAlign = HorizontalAlign.Center;
                    dayCell.Text = day;
                    tablerow.Cells.Add(dayCell);

                    TableCell timeCell = new TableCell();
                    timeCell.HorizontalAlign = HorizontalAlign.Center;
                    timeCell.Text = time;
                    tablerow.Cells.Add(timeCell);
                    

                    //Creates a button to remove a lecture from the lecturer's schedule
                    Button button = new Button();
                    button.ID = "buttonleft" + i.ToString();
                    button.Attributes.Add("runat", "server");
                    button.Text = "Remove";
                    //button.CommandArgument = module + "," + hiddenLecturer .Value + "." + semester + "/" + day + "#" + time;
                    button.CommandArgument = lectureId;
                    button.Command += new CommandEventHandler(example);

                    TableCell tablecellButton = new TableCell();
                    tablecellButton.Controls.Add(button);

                    tablerow.Cells.Add(tablecellButton);

                    table1.Rows.Add(tablerow);

                    table.Visible = true;

                    //table.EnableViewState = true;
                    //ViewState["table"] = true;

                    tableid++;
                  
                }
                else
                {
                    lblError.Text = j.ToString();
                }
            }
        }
        catch (Exception)
        {
            lblError.Text = "Please enter a valid semester or staff number.";
        }

    }

    //Deletes a particular lecture
    protected void example(Object sender, CommandEventArgs e)
    {
        lecturer = new Lecturer();

        //String c = e.CommandArgument.ToString();
        //int d = c.IndexOf (',');
        //String f = c.Substring(0, d);

        //lecturer.deleteModule(f, txtLecturerID.Text);

        //char[] delimiterChars = { ',', '.', '/', '#'};
        String s = e.CommandArgument.ToString();

        //String[] t = s.Split(delimiterChars);
        //lecturer.deleteModule(t[0],t[1],Convert .ToInt32 (t[2]), Convert .ToInt32 (t[3]), Convert .ToInt32 (t[4]));
        lecturer.deleteModuleLectureId(s);
        //Label5.Text = t[4];
        displayLectures(hiddenLecturer.Value);


    }

    //Displays the lectures of a particular lecturer
    protected void Button1_Click(object sender, EventArgs e)
    {
            displayLectures(DropDownStaff.SelectedValue);
            hiddenLecturer.Value = DropDownStaff.SelectedValue; //Assigns a hidden value to be read on postback
    }

    
    //This is unused code
    public void newRow()
    {

        getModule();

        TableRow tablerow = new TableRow();
        tablerow.ID = "tablerow" + tableid.ToString();
        //tablerow.ID = "tablerow1";

        TableCell tablecellDropDown = new TableCell();

        DropDownList dropdown = new DropDownList();
        dropdown.DataSource = moduleIDNew;
        dropdown.DataBind();

        if (ViewState["ddl_index"] != null)
        {
           dropdown.SelectedIndex = Convert.ToInt32(ViewState["ddl_index"]);
           tablecellDropDown.Text = dropdown.SelectedValue.ToString ();
        }
        else
        {
            tablecellDropDown.Controls.Add(dropdown);
        }

        dropdown.SelectedIndexChanged += dropExample;
        dropdown.AutoPostBack = true;       

        


        Button button = new Button();
        button.Attributes.Add("runat", "server");
        button.Text = "Save";
        button.CommandArgument = dropdown.SelectedValue;
        button.Command += new CommandEventHandler(example2);
        

        TableCell tablecellButton = new TableCell();
        tablecellButton.Controls.Add(button);

        tablerow.Cells.Add(tablecellDropDown);
        tablerow.Cells.Add(tablecellButton);
        table1.Rows.Add(tablerow);

        tableid++;

    }

    //This is an old button
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        
        //newRow();
        //HiddenField1.Value = "1";
    }

    //
    protected void getModule()
    {
        //Reads all modules
        moduleIDNew.Clear();

        lecturer = new Lecturer();

        lecturer.readModules();

        String module2;

        int j = lecturer.getModuleNewCount();

        //Label5.Text = j.ToString ();

        //Adds modules to an array
        for (int i = 0; i < j; i++)
        {

            module2 = lecturer.getModuleIDNew(i);

            moduleIDNew.Add(module2);
        }


    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        getModule();
    }

    //This is old code
    protected void example2(object sender, CommandEventArgs e)
    {
        //Label5.Text = e.CommandArgument.ToString();
        String a = e.CommandName.ToString();
    }

    //This is old code
    protected void dropExample(object sender, EventArgs e)
    {
       ViewState["ddl_index"] = ((DropDownList)sender).SelectedIndex;
    }

    //This saves a lecture
    protected void btnSave_Click(object sender, EventArgs e)
    {
        lecturer = new Lecturer();

        String x;
        if (DropDownList2.SelectedIndex == 0)
        {
            x = DropDownList1.SelectedValue + "/L".Trim();
        }
        else
        {
            x = DropDownList1.SelectedValue + "/T".Trim();
        }

        lecturer.writeLecture(x, hiddenLecturer.Value);
        displayLectures(hiddenLecturer .Value);
    }

    //This is old code
    protected void setDay(int a)
    {
        switch (a)
        {
            case 0:
                dayString = "Not set";
                break;

            case 1:
                dayString = "Monday";
                break;

            case 2:
                dayString = "Tuesday";
                break;

            case 3:
                dayString = "Wednesday";
                break;

            case 4:
                dayString = "Thursday";
                break;

            case 5:
                dayString = "Friday";
                break;

            case 6:
                dayString = "Saturday";
                break;

            case 7:
                dayString = "Sunday";
                break;
        }
    }

    //This is old code
    protected void setTime(int a)
    {
        switch (a)
        {
            case 0:
                timeString = "Not set";
                break;

            case 1:
                timeString = "8:00 - 9:00";
                break;

            case 2:
                timeString = "9:00 - 10:00";
                break;

            case 3:
                timeString = "10:00 - 11:00";
                break;

            case 4:
                timeString = "11:00- 12:00";
                break;

            case 5:
                timeString = "12:00 - 13:00";
                break;

            case 6:
                timeString = "13:00 - 14:00";
                break;

            case 7:
                timeString = "14:00 - 15:00";
                break;

            case 8:
                timeString = "15:00 - 16:00";
                break;

            case 9:
                timeString = "16:00 - 17:00";
                break;

            case 10:
                timeString = "17:00 - 18:00";
                break;

            case 11:
                timeString = "18:00 - 19:00";
                break;
        }
    }

    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/MainMenu.aspx");
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}