﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Save_YearSave2 : System.Web.UI.Page
{

    String roomID;
    String buildingID;
    List<String> moduleID = new List<String>();
    List<String> moduleIDNew = new List<String>();
    List<String> LectureID = new List<string>();
    List<String> RoomIdList2 = new List<string>();
    List<String> RoomIdList = new List<string>();
    List<String> YearIdList = new List<string>();
    String module;
    String staffId;
    String dayString;
    String timeString;
    String day;
    String time;
    int Semester;
    List<String> dayList = new List<string>();
    List<String> timeList = new List<string>();

    protected void Page_Load(object sender, EventArgs e)
    {

        //Populates dropdown boxes wit semesters, days and weeks
        if (!Page.IsPostBack)
        {
            DropDownSemester.Items.Add("1");
            DropDownSemester.Items.Add("2");
            DropDownSemester.DataBind();
            DropDownSemester.SelectedIndex = 0;

            DropDownType.Items.Add("Lecture");
            DropDownType.Items.Add("Tutorial");
            DropDownType.DataBind();
            DropDownType.SelectedIndex = 0;

            dayList.Add("Monday");
            dayList.Add("Tuesday");
            dayList.Add("Wednesday");
            dayList.Add("Thursday");
            dayList.Add("Friday");
            DropDownDay.DataSource = dayList;
            DropDownDay.DataBind();
            DropDownDay.SelectedIndex = 0;
            //DropDownDay.AutoPostBack = true;

            timeList.Add("8:00 - 9:00");
            timeList.Add("9:00 - 10:00");
            timeList.Add("10:00 - 11:00");
            timeList.Add("11:00 - 12:00");
            timeList.Add("12:00 - 13:00");
            timeList.Add("13:00 - 14:00");
            timeList.Add("14:00 - 15:00");
            timeList.Add("15:00 - 16:00");
            timeList.Add("16:00 - 17:00");
            timeList.Add("17:00 - 18:00");
            timeList.Add("18:00 - 19:00");
            DropDownTime.DataSource = timeList;
            DropDownTime.DataBind();
            DropDownTime.SelectedIndex = 0;
            //DropDownTime.AutoPostBack = true;

            //Populates dropdown box with list of years
            Year year = new Year();
            year.readYearFromYearTable();
            int j = year.countYearIdList();

            for (int i = 0; i < j; i++)
            {
                YearIdList.Add(year.getYearIdList(i));
            }

            DropDownYear.DataSource = YearIdList;
            DropDownYear.DataBind();
            DropDownYear.SelectedIndex = 0;
        }
        else
        {
            selectModules2(HiddenField1.Value, HiddenField2.Value);
        }
    }

    protected void selectModules2(String x, String y)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);

        //Clears table rows
        Table1.Rows.Clear();
        TableHeaderRow theadRow = new TableHeaderRow();

        //Creates header rows
        TableHeaderCell theadCellModule = new TableHeaderCell();
        theadCellModule.Text = "Module";
        TableHeaderCell theadCellWeek = new TableHeaderCell();
        theadCellWeek.Text = "Week";
        TableHeaderCell theadCellDay = new TableHeaderCell();
        theadCellDay.Text = "Day";
        TableHeaderCell theadCellTime = new TableHeaderCell();
        theadCellTime.Text = "Time";

        theadRow.Cells.Add(theadCellModule);
        theadRow.Cells.Add(theadCellWeek);
        theadRow.Cells.Add(theadCellDay);
        theadRow.Cells.Add(theadCellTime);

        Table1.Rows.Add(theadRow);

        //Selects modules of the selected year
        string sql = "select ModuleId from Module where Year = @Year";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@Year", x);
        List<String> modules = new List<string>();
        modules.Clear();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            modules.Add(dr["ModuleId"].ToString().Trim());
        }
        dr.Close();
        conn.Close();

        //Reads lectures belonging to the year's modules
        readLecture(modules, y);
    }

    protected void readLecture(List<String> modules, String y)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        int j = modules.Count();
        SqlDataAdapter da = new SqlDataAdapter();
       
        for (int i = 0; i < j; i++)
        {
            string sql = "select LectureId, ModuleId, SemesterId, Day, Time, Week from Lecture where ModuleId like @Module + '%' and SemesterId = @Year";
            conn.Open();
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Module", modules[i]);
            cmd.Parameters.AddWithValue("@Year", y);
            SqlDataReader dr = cmd.ExecuteReader();

            //Selects data from a particular lecture
            while (dr.Read())
            {
                String lectureid = dr["LectureId"].ToString();
                String moduleid = dr["ModuleId"].ToString();
                String week = dr["Week"].ToString();
                String day = dr["Day"].ToString();
                String time = dr["Time"].ToString();

                //Creates tables based on data selected
                createTables(lectureid, moduleid, week, day, time);

            }
            //Label1.Text = ds.Tables[0].Rows[0][1].ToString();
            //Label1.Text = dt.Rows[0][0].ToString();
            dr.Close();
            conn.Close();
        }
    }

    protected void createTables(String lectureId, String moduleId, String week, String day, String time)
    {
        
        //Creates table cells for data in parameters
        TableCell moduleCell = new TableCell();
        TableCell weekCell = new TableCell();
        TableCell dayCell = new TableCell();
        TableCell timeCell = new TableCell();

        TableRow tr = new TableRow();
        tr.ID = "Tablerow" + lectureId;

        //Populates cells
        moduleCell.Text = moduleId;
        weekCell.Text = week;
        weekCell.HorizontalAlign = HorizontalAlign.Center;
        dayCell.Text = day;
        dayCell.HorizontalAlign = HorizontalAlign.Center;
        timeCell.Text = time;
        timeCell.HorizontalAlign = HorizontalAlign.Center;

        //Creates 'Remove' button to delete lectures
        TableCell buttonCell = new TableCell();
        Button button = new Button();
        button.ID = "button" + Convert.ToInt32 (lectureId);
        button.Text = "Remove";
        button.CommandArgument = lectureId;
        button.Command += new CommandEventHandler(removeEntry);
        buttonCell.Controls.Add(button);

        //Adds cells to table
        tr.Cells.Add(moduleCell);
        tr.Cells.Add(weekCell);
        tr.Cells.Add(dayCell);
        tr.Cells.Add(timeCell);
        tr.Cells.Add(buttonCell);
        Table1.Rows.Add(tr);

        //Makes instruction labels visible
        Label3.Visible = true;
        Label4.Visible = true;
        Label5.Visible = true;
        Label6.Visible = true;
        Label9.Visible = true;

        //Makes dropdown boxes to add lectures visible
        Label7.Visible = true;
        DropDownDay.Visible = true;
        DropDownModule.Visible = true;
        DropDownTime.Visible = true;
        DropDownType.Visible = true;
        txtWeek.Visible = true;
        Button2.Visible = true;

    }

    protected void removeEntry(object sender, CommandEventArgs e)
    {
        //Deletes a lecture from the Lecture table
        Year year = new Year();
        year.deleteEntry(e.CommandArgument.ToString());
        selectModules2(HiddenField1.Value, HiddenField2 .Value);
    }

    //Populates dropdown box with modules of the selected year
    protected void selectModules()
    {
        moduleID.Clear();
        Year year = new Year();
        //Reads modules of selected year
        year.readModules(DropDownYear.SelectedValue);
        int j = year.getModuleCount();

        //Adds modules to an array
        for (int i = 0; i < j; i++)
        {
            moduleID.Add(year.getModuleID(i));
        }

        //Populates dropdown box
        DropDownModule.DataSource = moduleID;
        DropDownModule.DataBind();
        DropDownModule.SelectedIndex = 0;
        //DropDownModule.AutoPostBack = true;

    }

    //Populates module dropdown box and loads table of the year's lectures
    protected void Button1_Click(object sender, EventArgs e)
    {
        selectModules();
        selectModules2(DropDownYear.SelectedValue, DropDownSemester.SelectedValue);
        HiddenField1.Value = DropDownYear.SelectedValue;
        HiddenField2.Value = DropDownSemester.SelectedValue;
    }

    //Saves a new lecture for the selected year
    protected void Button2_Click(object sender, EventArgs e)
    {
        Year year = new Year();
        if (txtWeek.Text != "")
        {
            String x;
            if (DropDownType.SelectedIndex == 0 )
            {
                x = DropDownModule.SelectedValue + "/L".Trim();
            }
            else
            {
                x = DropDownModule.SelectedValue + "/T".Trim();
            }

            year.writeLecture(x, txtWeek.Text, DropDownDay.SelectedValue, DropDownTime.SelectedValue, Convert.ToInt32(DropDownSemester.SelectedValue));
            selectModules2(HiddenField1.Value, HiddenField2.Value);
            Label8.Text = "";
        }
        else
        {
            Label8.Text = "You must enter a week";
        }
    }

    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/MainMenu.aspx");
    }

}