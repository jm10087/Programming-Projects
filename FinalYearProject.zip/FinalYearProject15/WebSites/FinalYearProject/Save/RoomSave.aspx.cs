﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Save_RoomSave : System.Web.UI.Page
{
    String module;
    Room room;
    String roomId;
    String day;
    String time;
    int semester;
    List<TableRow> tablerowList = new List<TableRow>();
    List<String> moduleID = new List<String>();
    int tableid = 0;
    List<String> moduleIDNew = new List<string>();
    String dayString;
    String timeString;
    String LectureId;

    List<String> roomIdList = new List<string>();

    protected void Page_Load(object sender, EventArgs e)
    {

        //Populates dropdown boxes with lecturers (and modules, which can be saved)
        if (!Page.IsPostBack)
        {
            getModule();
            DropDownList1.DataSource = moduleIDNew;
            DropDownList1.DataBind();
            DropDownList1.SelectedIndex = 0;
            //DropDownList1.AutoPostBack = true;

            room = new Room();
            room.readFromRoomTable();
            int j = room.getRoomNullIdCount();
            for (int i = 0; i < j; i++)
            {
                roomIdList.Add(room.getRoomNullIdList(i));
            }

            DropDownRoom.DataSource = roomIdList;
            DropDownRoom.DataBind();
            DropDownRoom.SelectedIndex = 0;
            //DropDownRoom.AutoPostBack = true;

            DropDownList2.Items.Add("Lecture");
            DropDownList2.Items.Add("Tutorial");
            DropDownList2.DataBind();
            DropDownList2.SelectedIndex = 0;
        }

        //Reloads the dynamically created table on postback
        if (hiddenRoom.Value != "")
        {
            displayLectures(hiddenRoom.Value);
        }
        else
        {

        }

    }

    protected void displayLectures(String x)
    {

        //try
        //{

            moduleID.Clear();

            //Makes the controls used to add lectures visible
            DropDownList1.Visible = true;
            DropDownList2.Visible = true;
            lblAdd.Visible = true;
            btnSave.Visible = true;
           
            //Creates table
            Table table = new Table();

            roomId = x;

            //Selects lectures belonging to the selected room
            room = new Room();
            room.readRoomTestSave(roomId);
            int j = room.getModuleCount(); //Selects amount of lectures belonging to a particular lecturer


            //Deletes table rows before populating them again
            table1.Rows.Clear();

            //Creates header rows
            TableHeaderRow theadRow = new TableHeaderRow();

            TableHeaderCell theadCellYear = new TableHeaderCell();
            theadCellYear.Text = "Year";
            TableHeaderCell theadCellModule = new TableHeaderCell();
            theadCellModule.Text = "Module";
            TableHeaderCell theadCellSemester = new TableHeaderCell();
            theadCellSemester.Text = "Semester";
            TableHeaderCell theadCellWeek = new TableHeaderCell();
            theadCellWeek.Text = "Week";
            TableHeaderCell theadCellDay = new TableHeaderCell();
            theadCellDay.Text = "Day";
            TableHeaderCell theadCellTime = new TableHeaderCell();
            theadCellTime.Text = "Time";

            theadRow.Cells.Add(theadCellYear);
            theadRow.Cells.Add(theadCellModule);
            theadRow.Cells.Add(theadCellSemester);
            theadRow.Cells.Add(theadCellWeek);
            theadRow.Cells.Add(theadCellDay);
            theadRow.Cells.Add(theadCellTime);

            table1.Rows.Add(theadRow);

            //Reads data for each lecture of the selected room
            for (int i = 0; i < j; i++)
            {

                
                room.readRoomSave(roomId, i);
                LectureId = room.getLectureId();
                semester = room.getSemester();
                module = room.getModule();
                day = room.getDay();
                time = room.getTime();
                String week = room.getWeek();
                moduleID.Add(module);

                //setDay(day);
                //setTime(time);

                //Modules commonly contain excess information after a '/'
                if (module.Contains("/"))
                {
                    String module2 = module.Substring(0, module.IndexOf("/"));
                    room.readYearFromModule(module2);
                }
                else
                {
                    room.readYearFromModule(module);
                }

                //Determines the year of the currently selected module
                String yearId = room.getYear();

                //Polulates table based on read data
                if (module != null)
                {

                    TableRow tablerow = new TableRow();
                    tablerow.ID = "tablerow" + tableid.ToString();

                    TableCell tablecellYear = new TableCell();
                    tablecellYear.Text = yearId;

                    tablerow.Cells.Add(tablecellYear);

                    TableCell tablecellModule = new TableCell();
                    tablecellModule.Text = module;

                    tablerow.Cells.Add(tablecellModule);

                    TableCell semesterCell = new TableCell();
                    if (semester != 0)
                    {
                        semesterCell.Text = semester.ToString();
                    }
                    else
                    {
                        semesterCell.Text = "Not set";
                    }
                    semesterCell.HorizontalAlign = HorizontalAlign.Center;
                    tablerow.Cells.Add(semesterCell);

                    TableCell weekCell = new TableCell();
                    weekCell.HorizontalAlign = HorizontalAlign.Center;
                    weekCell.Text = week;
                    tablerow.Cells.Add(weekCell);

                    TableCell dayCell = new TableCell();
                    dayCell.HorizontalAlign = HorizontalAlign.Center;
                    dayCell.Text = day;
                    tablerow.Cells.Add(dayCell);

                    TableCell timeCell = new TableCell();
                    timeCell.HorizontalAlign = HorizontalAlign.Center;
                    timeCell.Text = time;
                    tablerow.Cells.Add(timeCell);

                    //Creates a button to remove a lecture from the room's schedule
                    Button button = new Button();
                    button.ID = "buttonleft" + i.ToString();
                    button.Attributes.Add("runat", "server");
                    button.Text = "Remove";
                    //button.CommandArgument = module + "," + hiddenRoom.Value + "." + semester + "/" + day + "#" + time;
                    button.CommandArgument = LectureId;
                    button.Command += new CommandEventHandler(example);

                    TableCell tablecellButton = new TableCell();
                    tablecellButton.Controls.Add(button);

                    tablerow.Cells.Add(tablecellButton);

                    table1.Rows.Add(tablerow);

                    table.Visible = true;

                    tableid++;

                }
                else
                {
                    lblError.Text = j.ToString();
                }
            }
       // }
       // catch (Exception ex)
       // {
       //     lblError.Text = "Please enter a valid semester or staff number.";
       // }

    }

    //Deletes a particular lecture
    protected void example(Object sender, CommandEventArgs e)
    {
        room = new Room();

        //char[] delimiterChars = { ',', '.', '/', '#' };
        String s = e.CommandArgument.ToString();

        //String[] t = s.Split(delimiterChars);
        //room.deleteModule(t[0], t[1], Convert.ToInt32(t[2]), Convert.ToInt32(t[3]), Convert.ToInt32(t[4]));
        room.deleteModuleLectureId(s);
        displayLectures(hiddenRoom .Value);


    }

    //Displays the lectures of a particular room
    protected void Button1_Click(object sender, EventArgs e)
    {
            displayLectures(DropDownRoom .SelectedValue);
            hiddenRoom.Value = DropDownRoom.SelectedValue; //Assigns a hidden value to be read on postback
    }


    //This is old code
    protected void getModule()
    {
        moduleIDNew.Clear();

        room = new Room();

        room.readModules();

        String module2;

        int j = room.getModuleNewCount();

        for (int i = 0; i < j; i++)
        {

            module2 = room.getModuleIDNew(i);

            moduleIDNew.Add(module2);
        }
    }


    //This saves a new lecture assigned to the selected room
    protected void btnSave_Click(object sender, EventArgs e)
    {
        room = new Room();

        String x;
        if (DropDownList2.SelectedIndex == 0)
        {
            x = DropDownList1.SelectedValue + "/L".Trim();
        }
        else
        {
            x = DropDownList1.SelectedValue + "/T".Trim();
        }

        room.writeRoom(x, hiddenRoom.Value);
        displayLectures(hiddenRoom.Value);
    }

    //This is old code
    protected void setDay(int a)
    {
        switch (a)
        {
            case 0:
                dayString = "Not set";
                break;

            case 1:
                dayString = "Monday";
                break;

            case 2:
                dayString = "Tuesday";
                break;

            case 3:
                dayString = "Wednesday";
                break;

            case 4:
                dayString = "Thursday";
                break;

            case 5:
                dayString = "Friday";
                break;

            case 6:
                dayString = "Saturday";
                break;

            case 7:
                dayString = "Sunday";
                break;
        }
    }

    //This is old code
    protected void setTime(int a)
    {
        switch (a)
        {
            case 0:
                timeString = "Not set";
                break;

            case 1:
                timeString = "8:00 - 9:00";
                break;

            case 2:
                timeString = "9:00 - 10:00";
                break;

            case 3:
                timeString = "10:00 - 11:00";
                break;

            case 4:
                timeString = "11:00- 12:00";
                break;

            case 5:
                timeString = "12:00 - 13:00";
                break;

            case 6:
                timeString = "13:00 - 14:00";
                break;

            case 7:
                timeString = "14:00 - 15:00";
                break;

            case 8:
                timeString = "15:00 - 16:00";
                break;

            case 9:
                timeString = "16:00 - 17:00";
                break;

            case 10:
                timeString = "17:00 - 18:00";
                break;

            case 11:
                timeString = "18:00 - 19:00";
                break;
        }
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/MainMenu.aspx");
    }
}