﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Clashes_YearClashes2 : System.Web.UI.Page
{
    String roomID;
    String buildingID;
    List<String> moduleID = new List<String>();
    List<String> moduleIDNew = new List<String>();
    List<String> LectureID = new List<string>();
    List<String> RoomIdList2 = new List<string>();
    List<String> RoomIdList = new List<string>();
    List<String> YearIdList = new List<string>();
    List<String> duplicate = new List<string>();
    String module;
    String staffId;
    String dayString;
    String timeString;
    String day;
    String time;
    int Semester;

    DataSet dsFinal = new DataSet();
    DataTable dt = new DataTable();

    protected void Page_Load(object sender, EventArgs e)
    {
        selectModules2(Session ["String"].ToString()); //Loads data based on year selected in YearClashes
        //selectModules2 ("BIS1".ToString());

        //Ensure table reloads on postback
        if (HiddenField1.Value != "")
        {
            char[] delimiterChars = { '^', '#', '|' };
            String s = HiddenField1.Value.ToString();

            String[] t = s.Split(delimiterChars);
            showLectures(t[0], t[1], t[2]);
        }
        
    }

    //This gets the amount of years in the system
   

    //This is an old version of 'SelectModules2' below 
    protected void selectModules(List<String> years)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        int j = years.Count();
        for (int i = 0; i < j; i++)
        {
            string sql = "select ModuleId from Module where Year = 'BIS1'";
            conn.Open();
            SqlCommand cmd = new SqlCommand(sql, conn);
            List<String> modules = new List<string>();
            modules.Clear(); //Clears list of old year's modules
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read()) //Repeats for all modules in year
            {
                modules.Add(dr["ModuleId"].ToString().Trim());
            }
            readLecture(modules); //fill datatable
            lectureTest(); //discover clashes
        }
    }


    //This fills a datatable with all the lectures of a particular year.
    protected void readLecture(List<String> modules)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        int j = modules.Count();
        SqlDataAdapter da = new SqlDataAdapter();
        dt.Clear();
        for (int i = 0; i < j; i++)
        {
            string sql = "select LectureId, ModuleId, SemesterId, Day, Time from Lecture where ModuleId like '" + modules[i] + "%'";
            conn.Open();
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataReader dr = cmd.ExecuteReader();
            DataSet ds = new DataSet();
            DataTable dta = new DataTable();
            SqlDataAdapter data = new SqlDataAdapter("select LectureId, ModuleId, SemesterId, Day, Time, Week from Lecture where ModuleId like '"+modules[i]+"%' and Day is not null and Time is not null and Week is not null and SemesterId is not null", connectionString);
            data.Fill(dt);
            //Label1.Text = ds.Tables[0].Rows[0][1].ToString();
            //Label1.Text = dt.Rows[0][0].ToString();
            dr.Close();
            conn.Close();
        }
    }

    //This checks for clashes and crestes a table showing when lectures are clashing.
    public void lectureTest()
    {
        //Amount of rows in the datatable
        int j = dt.Rows.Count;

        Table1.Rows.Clear(); //Clears table rows
        duplicate.Clear();

        //Creates headers
        TableHeaderRow theadRow = new TableHeaderRow();

        TableHeaderCell theadCellSemester = new TableHeaderCell();
        theadCellSemester.Text = "Semester";
       //TableHeaderCell theadCellWeek = new TableHeaderCell();
        //theadCellWeek.Text = "Week";
        TableHeaderCell theadCellDay = new TableHeaderCell();
        theadCellDay.Text = "Day";
        TableHeaderCell theadCellTime = new TableHeaderCell();
        theadCellTime.Text = "Time";

        theadRow.Cells.Add(theadCellSemester);
        //theadRow.Cells.Add(theadCellWeek);
        theadRow.Cells.Add(theadCellDay);
        theadRow.Cells.Add(theadCellTime);

        

        Table1.Rows.Add(theadRow);

        //Assigns variables for each Lecture in the datatable
        for (int i = 0; i < j; i++)
        {
            String LectureId = dt.Rows[i][0].ToString();
            String module = dt.Rows[i][1].ToString();
            String semester = dt.Rows[i][2].ToString();
            String day = dt.Rows[i][3].ToString();
            String time = dt.Rows[i][4].ToString();
            //String week = dt.Rows[i][5].ToString();

            for (int k = 0; k < j; k++)
            {
                if (LectureId != dt.Rows[k][0].ToString() && semester == dt.Rows[k][2].ToString() && day == dt.Rows[k][3].ToString() && time == dt.Rows[k][4].ToString())
                {
                    Year year = new Year();
                    //Reads the year of the selected module
                    //ModuleIds frequently contain excess information after a '/'
                    if (module.Contains("/"))
                    {
                        String module2 = module.Substring(0, module.IndexOf("/"));
                        year.readYearFromModule(module2);
                    }
                    else
                    {
                        year.readYearFromModule(module);
                    }

                    String tempYear = semester+day+time;

                    //Ensuring the same time does not appear in the table twice
                    if (!duplicate.Contains(tempYear))
                    {
                        TableRow tr = new TableRow();
                        tr.ID = "tr" + i.ToString();

                        TableCell moduleCell = new TableCell();
                        TableCell semesterCell = new TableCell();
                        //TableCell weekCell = new TableCell();
                        TableCell dayCell = new TableCell();
                        TableCell timeCell = new TableCell();

                        //setDay(Convert.ToInt32(day));
                        //setTime(Convert.ToInt32(time));

                        //Add to duplicates array
                        duplicate.Add(tempYear);
                        moduleCell.Text = module;
                        semesterCell.Text = semester;
                        semesterCell.HorizontalAlign = HorizontalAlign.Center;
                        //weekCell.Text = week;
                       //weekCell.HorizontalAlign = HorizontalAlign.Center;
                        dayCell.Text = day;
                        dayCell.HorizontalAlign = HorizontalAlign.Center;
                        timeCell.Text = time;
                        timeCell.HorizontalAlign = HorizontalAlign.Center;

                        //Button to show list of lectures that are clashing
                        TableCell buttonCell = new TableCell();
                        Button button = new Button();
                        button.ID = "button" + i;
                        button.Text = "Show Clashes";
                        button.CommandArgument = semester + "^" + day + "#" + time;
                        button.Command += new CommandEventHandler(nextTable);
                        buttonCell.Controls.Add(button);

                        //Add cells to table
                        tr.Cells.Add(semesterCell);
                        //tr.Cells.Add(weekCell);
                        tr.Cells.Add(dayCell);
                        tr.Cells.Add(timeCell);
                        tr.Cells.Add(buttonCell);
                        Table1.Rows.Add(tr);
                    }
                }
            }
        }
    }

    //Displays lectures that are clashing at a particular time (the user clicks on a time in the first table, crested above)
    public void showLectures(String semesterParam, String dayParam, String timeParam)
    {

        int j = dt.Rows.Count;

        Table2.Rows.Clear();

        //Naming the columns in the datatable
        dt.Columns[2].ColumnName = "SemesterId";
        //dt.Columns[2].DataType = System.Type.GetType("System.Int32");
        dt.Columns[3].ColumnName = "Day";
        //dt.Columns[3].DataType = System.Type.GetType("System.String");
        dt.Columns[4].ColumnName = "Time";
        //dt.Columns[4].DataType = System.Type.GetType("System.String");

        //Selects the amount of semesters, days and times of the selected clash from the datatable
        DataRow[] semesterCount;
        semesterCount = dt.Select("SemesterId >= " + Convert.ToInt32(semesterParam));

        DataRow[] dayCount;
        dayCount = dt.Select("Day = '" + dayParam + "'");

        DataRow[] timeCount;
        timeCount = dt.Select("Time = '" + timeParam + "'");

        //Creates table if there is more than one lecture at the selected time (can happen if lecture is deleted)
        if (semesterCount.Count() > 1 && dayCount.Count() > 1 && timeCount.Count() > 1)
        {
            //Creates header rows for second table
            TableHeaderRow theadRow = new TableHeaderRow();

            TableHeaderCell theadCellModule = new TableHeaderCell();
            theadCellModule.Text = "Module";
            TableHeaderCell theadCellSemester = new TableHeaderCell();
            theadCellSemester.Text = "Semester";
            TableHeaderCell theadCellWeek = new TableHeaderCell();
            theadCellWeek.Text = "Week";
            TableHeaderCell theadCellDay = new TableHeaderCell();
            theadCellDay.Text = "Day";
            TableHeaderCell theadCellTime = new TableHeaderCell();
            theadCellTime.Text = "Time";

            theadRow.Cells.Add(theadCellModule);
            theadRow.Cells.Add(theadCellSemester);
            theadRow.Cells.Add(theadCellWeek);
            theadRow.Cells.Add(theadCellDay);
            theadRow.Cells.Add(theadCellTime);

            Table2.Rows.Add(theadRow);

            //Creates variables for clashing lectures
            for (int i = 0; i < j; i++)
            {
                String LectureId = dt.Rows[i][0].ToString();
                String module = dt.Rows[i][1].ToString();
                String semester = dt.Rows[i][2].ToString();
                String day = dt.Rows[i][3].ToString();
                String time = dt.Rows[i][4].ToString();
                String week = dt.Rows[i][5].ToString();

                //Checks if cells match the selected day, time and semester
                if (semesterParam == dt.Rows[i][2].ToString() && dayParam == dt.Rows[i][3].ToString() && timeParam == dt.Rows[i][4].ToString())
                {
                    TableRow tr = new TableRow();
                    tr.ID = "trx" + i.ToString();

                    TableCell moduleCell = new TableCell();
                    TableCell semesterCell = new TableCell();
                    TableCell weekCell = new TableCell();
                    TableCell dayCell = new TableCell();
                    TableCell timeCell = new TableCell();

                    //setDay(Convert.ToInt32(day));
                    //setTime(Convert.ToInt32(time));

                    moduleCell.Text = module;
                    semesterCell.Text = semester;
                    semesterCell.HorizontalAlign = HorizontalAlign.Center;
                    weekCell.Text = week;
                    weekCell.HorizontalAlign = HorizontalAlign.Center;
                    dayCell.Text = day;
                    dayCell.HorizontalAlign = HorizontalAlign.Center;
                    timeCell.Text = time;
                    timeCell.HorizontalAlign = HorizontalAlign.Center;

                    //Creates button to delete lectures
                    TableCell buttonCell = new TableCell();
                    Button button = new Button();
                    button.ID = "buttonx" + i;
                    button.Text = "Remove";
                    button.CommandArgument = LectureId;
                    button.Command += new CommandEventHandler(deleteButton);
                    buttonCell.Controls.Add(button);

                    tr.Cells.Add(moduleCell);
                    tr.Cells.Add(semesterCell);
                    tr.Cells.Add(weekCell);
                    tr.Cells.Add(dayCell);
                    tr.Cells.Add(timeCell);
                    tr.Cells.Add(buttonCell);
                    Table2.Rows.Add(tr);
                }
            }
        }
    }



    //This is basic dataset code.
    protected void temporary()
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "select ModuleId, Day, Time from Lecture where LectureId = '1'";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader dr = cmd.ExecuteReader();
        DataSet ds = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter("select ModuleId, Day, Time from Lecture where LectureId = '1'" + "select ModuleId, Day, Time from Lecture where LectureId = '2'", connectionString);
        da.Fill(ds);
        //Label1.Text = ds.Tables[0].Rows[0][2].ToString();
        dr.Close();
        conn.Close();
    }

    //This selects the amount of modules a year has. It will loop for all years.
    protected void selectModules2(String x)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);

        string sql = "select ModuleId from Module where Year = @Year";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@Year", x);
        List<String> modules = new List<string>();
        modules.Clear();//Clears list of old year's modules
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read()) //Repeats for all modules in year
        {
            modules.Add(dr["ModuleId"].ToString().Trim());
        }
        dr.Close();
        conn.Close();

        readLecture(modules); //fill datatable
        lectureTest(); //discover clashes
    }

    //This is old code
    protected void setDay(int a)
    {
        switch (a)
        {
            case 1:
                dayString = "Monday";
                break;

            case 2:
                dayString = "Tuesday";
                break;

            case 3:
                dayString = "Wednesday";
                break;

            case 4:
                dayString = "Thursday";
                break;

            case 5:
                dayString = "Friday";
                break;

            case 6:
                dayString = "Saturday";
                break;

            case 7:
                dayString = "Sunday";
                break;
        }
    }

    protected void setTime(int a)
    {
        switch (a)
        {
            case 1:
                timeString = "8:00 - 9:00";
                break;

            case 2:
                timeString = "9:00 - 10:00";
                break;

            case 3:
                timeString = "10:00 - 11:00";
                break;

            case 4:
                timeString = "11:00- 12:00";
                break;

            case 5:
                timeString = "12:00 - 13:00";
                break;

            case 6:
                timeString = "13:00 - 14:00";
                break;

            case 7:
                timeString = "14:00 - 15:00";
                break;

            case 8:
                timeString = "15:00 - 16:00";
                break;

            case 9:
                timeString = "16:00 - 17:00";
                break;

            case 10:
                timeString = "17:00 - 18:00";
                break;

            case 11:
                timeString = "18:00 - 19:00";
                break;
        }
    }

    //This calls methods to show which lectures are clashing when the user clicks on a time that lectures are clashing
    public void nextTable(object sender, CommandEventArgs e)
    {

        char[] delimiterChars = { '^', '#'};
        String s = e.CommandArgument.ToString();

        String[] t = s.Split(delimiterChars);
        showLectures(t[0], t[1], t[2]);

        HiddenField1.Value = s;

    }

    
    public void deleteButton(object sender, CommandEventArgs e)
    {
        String s = e.CommandArgument.ToString();
        deleteClash(s); //Remove lecture from schedule
        //selectModules2(Session["String"].ToString());
        selectModules2("BIS1".ToString());

        if (HiddenField1.Value != "")
        {
            char[] delimiterChars = { '^', '#', '|' };
            String d = HiddenField1.Value.ToString();

            String[] t = d.Split(delimiterChars);
            selectModules2(Session["String"].ToString()); //Displays second table on postback
            showLectures(t[0], t[1], t[2]);
        }
    }

    //This removes a lecture from its schedule
    protected void deleteClash(String lectureParam)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();
        SqlCommand cmd = new SqlCommand("Update Lecture set SemesterId = null, Day = null, Time = null, Week = null where LectureId = @LectureId", conn);
        cmd.Parameters.AddWithValue("@LectureId", lectureParam);
        cmd.ExecuteNonQuery();
        conn.Close();
    }

    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("YearClashes.aspx");
    }
}