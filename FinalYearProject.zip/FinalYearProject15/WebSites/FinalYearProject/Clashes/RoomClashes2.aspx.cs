﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Clashes_RoomClashes2 : System.Web.UI.Page
{
    Room room;
    String module;
    String lecturer;
    String staffId;
    String day;
    String time;
    int semester;
    List<TableRow> tablerowList = new List<TableRow>();
    List<String> moduleID = new List<String>();
    int tableid = 0;
    List<String> moduleIDNew = new List<string>();
    String test1;
    String dayString;
    String timeString;
    List<String> staffIdList = new List<string>();
    List<String> lectureID = new List<string>();
    List<int> semesterList = new List<int>();
    List<String> dayList = new List<String>();
    List<String> timeList = new List<String>();
    int tableid2 = 0;
    List<String> lectureID2 = new List<string>();

    protected void Page_Load(object sender, EventArgs e)
    {
        //Gets room id from RoomClashes
        showAllClashes(Session["text"].ToString());
        //showAllClashes("Room2");

        //Loads table on popstback
        if (HiddenField1.Value != "")
        {
            char[] delimiterChars = { '^', '#', '|' };
            test1 = HiddenField1.Value.ToString();

            String[] t = test1.Split(delimiterChars);
            displayClashes(t[0], Convert.ToInt32(t[1]), t[2], t[3]);
        }
    }

    //Displays a list of times that lectures are clashing at
    protected void showAllClashes(String RoomParam)
    {
        room = new Room();
        room.readRoomCompare(RoomParam); //Determines which lectures are clashing

        //Clears table rows
        table1.Rows.Clear();

        //Clears arrays

        semesterList.Clear();
        dayList.Clear();
        timeList.Clear();
        lectureID.Clear();

        String lectureId;
        String semesterClash;

        //Counts amount of lectures that are clashing
        int j = room.countLectureIdList();

        //Adds all lecture ids to an array
        for (int i = 0; i < j; i++)
        {
            lectureID.Add(room.getLectureIdList(i));
        }

        //Creates header rows
        TableHeaderRow theadRow = new TableHeaderRow();

        TableHeaderCell theadCellSemester = new TableHeaderCell();
        theadCellSemester.Text = "Semester";
        TableHeaderCell theadCellDay = new TableHeaderCell();
        theadCellDay.Text = "Day";
        TableHeaderCell theadCellTime = new TableHeaderCell();
        theadCellTime.Text = "Time";

        theadRow.Cells.Add(theadCellSemester);
        theadRow.Cells.Add(theadCellDay);
        theadRow.Cells.Add(theadCellTime);

        table1.Rows.Add(theadRow);

        //Creates test variable
        int test = 0;

        for (int i = 0; i < j; i++)
        {

            lectureId = lectureID[i];

            room.readRoomModules(lectureId);

            semesterClash = room.getSemester().ToString();
            //setDay(room.getDay());
            //setTime(room.getTime());
            String day1 = room.getDay();
            String time1 = room.getTime();

            //Ensures that the same time does not appear more than once in the table
            for (int l = 0; l < semesterList.Count; l++)
            {
                if (semesterClash == semesterList[l].ToString() && day1 == dayList[l] && time1 == timeList[l])
                {
                    test = 1;
                    break;
                }
                else
                {
                    test = 0;
                }
            }

            //Populates table with times that lectures are clashing
            if (test == 0)
            {
                semesterList.Add(room.getSemester());
                dayList.Add(day1);
                timeList.Add(time1);

                TableRow tablerow = new TableRow();
                tablerow.ID = "tablerow" + tableid2.ToString();

                TableCell semesterCell = new TableCell();
                semesterCell.Text = semesterClash;
                semesterCell.HorizontalAlign = HorizontalAlign.Center;
                tablerow.Cells.Add(semesterCell);

                TableCell dayCell = new TableCell();
                dayCell.Text = day1;
                tablerow.Cells.Add(dayCell);
                dayCell.HorizontalAlign = HorizontalAlign.Center;

                TableCell timeCell = new TableCell();
                timeCell.Text = time1;
                tablerow.Cells.Add(timeCell);
                timeCell.HorizontalAlign = HorizontalAlign.Center;

                //Creates button to view clashes in detail
                Button button = new Button();
                button.ID = "buttonleft" + i.ToString();
                button.Attributes.Add("runat", "server");
                button.Text = "View Clashes";
                button.CommandArgument = RoomParam + "^" + room.getSemester().ToString() + "#" + room.getDay().ToString() + "|" + room.getTime().ToString();
                button.Command += new CommandEventHandler(example);

                TableCell tablecellButton = new TableCell();
                tablecellButton.Controls.Add(button);

                tablerow.Cells.Add(tablecellButton);

                table1.Rows.Add(tablerow);

                table1.Visible = true;

                tableid2++;
            }



            // if (newRows.Count > 0)
            //{
            //  foreach (TableRow dr in newRows)
            //{
            //  table2.Rows.Add(dr);
            //}



            // }

        }

    }

    protected void example(object sender, CommandEventArgs e)
    {
        //Splits argument up into lecturer, semester, day and time parts
        char[] delimiterChars = { '^', '#', '|' };
        test1 = e.CommandArgument.ToString();
        HiddenField1.Value = e.CommandArgument.ToString(); //Ensures that table loads on postback

        String[] t = test1.Split(delimiterChars);
        displayClashes(t[0], Convert.ToInt32(t[1]), t[2], t[3]); //Displays clashes based on passed data
    }

    //Displays lectures that are clashing at a particular time
    protected void displayClashes(String lecturerParam, int semester, String day, String time)
    {
        try
        {

        //Clears arrays
        moduleID.Clear();
        lectureID2.Clear();
        table2.Rows.Clear();

        //Reads lectures of the selected room at the selected time
        room = new Room();
        room.readRoomFinal(lecturerParam, semester, day, time);
        int j = room.countLectureIdList(); //Counts the amount of lectures at the selected time

        if (j > 1)
        {
            //Adds lecture ids to array
            for (int i = 0; i < j; i++)
            {
                lectureID2.Add(room.getLectureIdList(i));
            }

            table2.Rows.Clear();

            //Creates header rows
            TableHeaderRow theadRow = new TableHeaderRow();

            TableHeaderCell theadCellYear = new TableHeaderCell();
            theadCellYear.Text = "Year";
            TableHeaderCell theadCellModule = new TableHeaderCell();
            theadCellModule.Text = "Module";
            TableHeaderCell theadCellSemester = new TableHeaderCell();
            theadCellSemester.Text = "Semester";
            TableHeaderCell theadCellWeek = new TableHeaderCell();
            theadCellWeek.Text = "Week";
            TableHeaderCell theadCellDay = new TableHeaderCell();
            theadCellDay.Text = "Day";
            TableHeaderCell theadCellTime = new TableHeaderCell();
            theadCellTime.Text = "Time";

            theadRow.Cells.Add(theadCellYear);
            theadRow.Cells.Add(theadCellModule);
            theadRow.Cells.Add(theadCellSemester);
            theadRow.Cells.Add(theadCellWeek);
            theadRow.Cells.Add(theadCellDay);
            theadRow.Cells.Add(theadCellTime);

            table2.Rows.Add(theadRow);

            for (int i = 0; i < j; i++)
            {
                //Selects day, time, week and semester of each lecture in the loop
                room.readRoomFinal2(lectureID2[i]);

                //Assigns attributes to variables
                module = room.getModule();
                semester = room.getSemester();
                day = room.getDay();
                //setDay(day);
                time = room.getTime();
                String week = room.getWeek();
                //setTime(time);

                //Reads the year of the selected module
                //ModuleIds frequently contain excess information after a '/'
                if (module.Contains("/"))
                {
                    String module2 = module.Substring(0, module.IndexOf("/"));
                    room.readYearFromModule(module2);
                }
                else
                {
                    room.readYearFromModule(module);
                }

                String yearId = room.getYear();

                //Creates table rows
                TableRow tablerow = new TableRow();
                tablerow.ID = "newtablerow" + tableid.ToString();

                TableCell tablecellYear = new TableCell();
                tablecellYear.Text = yearId;

                TableCell tableCellModule = new TableCell();
                tableCellModule.Text = module;

                TableCell tableCellSemester = new TableCell();
                tableCellSemester.Text = semester.ToString();
                tableCellSemester.HorizontalAlign = HorizontalAlign.Center;

                TableCell tableCellWeek = new TableCell();
                tableCellWeek.Text = week;

                TableCell tableCellDay = new TableCell();
                tableCellDay.Text = day;

                TableCell tableCellTime = new TableCell();
                tableCellTime.Text = time;

                tablerow.Cells.Add(tablecellYear);
                tablerow.Cells.Add(tableCellModule);
                tablerow.Cells.Add(tableCellSemester);
                tablerow.Cells.Add(tableCellWeek);
                tablerow.Cells.Add(tableCellDay);
                tablerow.Cells.Add(tableCellTime);

                //Creates the button to delete the lecture
                Button button = new Button();
                button.ID = "buttonright" + i.ToString();
                button.Attributes.Add("runat", "server");
                button.Text = "Remove";
                button.CommandArgument = lectureID2[i] + "^" + lecturerParam + "#" + semester + "|" + day + "~" + time;
                button.Command += new CommandEventHandler(firstButton);

                TableCell tablecellButton = new TableCell();
                tablecellButton.Controls.Add(button);

                tablerow.Cells.Add(tablecellButton);

                table2.Rows.Add(tablerow);

                tableid++;

            }
        }
        }
        catch (Exception ex)
        {
          //lblError.Text = "Please enter a valid semester or staff number.";
        }
    }

    protected void firstButton(object sender, CommandEventArgs e)
    {
        room = new Room();

        //Splits argument into LectureId, lecturer, semester, day and time
        char[] delimiterChars = { '^', '#', '|', '~' };
        String x = e.CommandArgument.ToString();

        String[] t = x.Split(delimiterChars);

        room.deleteModuleClash(t[0]); //Deletes the selected lecture from the room's schedule
        showAllClashes(Session["text"].ToString());
        displayClashes(t[1], Convert.ToInt32(t[2]), t[3], t[4]); //Loads table after logic has been completed
    }

    //This is old code
    protected void setDay(int a)
    {
        switch (a)
        {
            case 1:
                dayString = "Monday";
                break;

            case 2:
                dayString = "Tuesday";
                break;

            case 3:
                dayString = "Wednesday";
                break;

            case 4:
                dayString = "Thursday";
                break;

            case 5:
                dayString = "Friday";
                break;

            case 6:
                dayString = "Saturday";
                break;

            case 7:
                dayString = "Sunday";
                break;
        }
    }

    //This is old code
    protected void setTime(int a)
    {
        switch (a)
        {
            case 1:
                timeString = "8:00 - 9:00";
                break;

            case 2:
                timeString = "9:00 - 10:00";
                break;

            case 3:
                timeString = "10:00 - 11:00";
                break;

            case 4:
                timeString = "11:00- 12:00";
                break;

            case 5:
                timeString = "12:00 - 13:00";
                break;

            case 6:
                timeString = "13:00 - 14:00";
                break;

            case 7:
                timeString = "14:00 - 15:00";
                break;

            case 8:
                timeString = "15:00 - 16:00";
                break;

            case 9:
                timeString = "16:00 - 17:00";
                break;

            case 10:
                timeString = "17:00 - 18:00";
                break;

            case 11:
                timeString = "18:00 - 19:00";
                break;
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {

    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Clashes/RoomClashes.aspx");
    }
}