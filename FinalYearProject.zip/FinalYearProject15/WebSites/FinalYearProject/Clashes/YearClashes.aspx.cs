﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Clashes_YearClashes : System.Web.UI.Page
{

    String roomID;
    String buildingID;
    List<String> moduleID = new List<String>();
    List<String> moduleIDNew = new List<String>();
    List<String> LectureID = new List<string>();
    List<String> RoomIdList2 = new List<string>();
    List<String> RoomIdList = new List<string>();
    List<String> YearIdList = new List<string>();
    String module;
    String staffId;
    String day;
    String time;
    int Semester;
    int tableid = 0;

    DataSet dsFinal = new DataSet();
    DataTable dt = new DataTable();

    protected void Page_Load(object sender, EventArgs e)
    {
        //selectModules2();
        selectyearAmount();
    }

    //This selects the amount of years in the system
    protected void selectyearAmount()
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "select YearId from Year"; //Selects a list of years
        List<String> years = new List<string>();
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            years.Add(dr["YearId"].ToString());//Adds year ids to array
        }
        dr.Close();
        conn.Close();

        selectModules(years);
    }

    //This selects the amount of modules a year has. It will loop for all years. 
    protected void selectModules(List<String> years)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        int j = years.Count();
        
        Table1.Rows.Clear();

        if (j > 0)
        {
            //Creates header rows
            TableHeaderRow theadRow = new TableHeaderRow();

            TableHeaderCell theadCellYears = new TableHeaderCell();
            theadCellYears.Text = "Years";

            //Table1.Rows.Clear();

            theadRow.Cells.Add(theadCellYears);

            Table1.Rows.Add(theadRow);
        }

        List<String> modules = new List<string>();
        
        //Reads modules for all years and carries out logic with them
        for (int i = 0; i < j; i++)
        {
            dt.Clear();
            modules.Clear(); //Clears list of old year's modules
            string sql = "select ModuleId from Module where Year = @Year";
            conn.Open();
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Year", years[i]);
           
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read()) //Repeats for all modules in year
            {
                modules.Add(dr["ModuleId"].ToString().Trim());
            }
            dr.Close();
            conn.Close();

            readLecture(modules); //fill datatable
            lectureTest(); //discover clashes
            }

        
    }

   
    //This fills a datatable with all the lectures of a particular year.
    protected void readLecture(List<String> modules)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        int j = modules.Count();
        SqlDataAdapter da = new SqlDataAdapter();
        for (int i = 0; i < j; i++)
        {
            string sql = "select LectureId, ModuleId, SemesterId, Day, Time from Lecture where ModuleId = @ModuleId";
            conn.Open();
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@ModuleId", modules[i]);
            SqlDataReader dr = cmd.ExecuteReader();
            DataSet ds = new DataSet();
            DataTable dta = new DataTable();
            SqlDataAdapter data = new SqlDataAdapter("select LectureId, ModuleId, SemesterId, Day, Time from Lecture where ModuleId like '" + modules[i] + "%' and Day is not null", connectionString);
            data.Fill(dt);
            //Label1.Text = ds.Tables[0].Rows[0][1].ToString();
            //Label1.Text = dt.Rows[0][0].ToString();
            dr.Close();
            conn.Close();
        }
    }

    //This checks for clashes.
    public void lectureTest()
    {
        //How many rows in the datatable
        int j = dt.Rows.Count;

              

        for (int i = 0; i < j; i++) 
        {
            //Assigns variables for each lecture in the datatable
            String LectureId = dt.Rows[i][0].ToString();
            String module = dt.Rows[i][1].ToString();
            String semester = dt.Rows[i][2].ToString();
            String day = dt.Rows[i][3].ToString();
            String time = dt.Rows[i][4].ToString();

            for(int k = 0; k<j; k++)
            {
                //Checks for clashes
                if (LectureId != dt.Rows[k][0].ToString() && semester == dt.Rows[k][2].ToString() && day == dt.Rows[k][3].ToString() && time == dt.Rows[k][4].ToString())
                {
                    Year year = new Year();

                    //Reads the year of the selected module
                    //ModuleIds frequently contain excess information after a '/'
                    if (module.Contains("/"))
                    {
                        String module2 = module.Substring(0, module.IndexOf("/"));
                        year.readYearFromModule(module2);
                    }
                    else
                    {
                        year.readYearFromModule(module);
                    }


                    String tempYear = year.getYear();

                    //Ensuring the same year does not appear in the table twice
                    if (!YearIdList.Contains(tempYear))
                    {
                        TableRow tr = new TableRow();
                        tr.ID = "tr" + tableid.ToString();

                        TableCell yearCell = new TableCell();

                        //Adds year to array
                        YearIdList.Add(tempYear);
                        yearCell.Text = tempYear;

                        //Adds button to view clashes
                        TableCell buttonCell = new TableCell();
                        Button button = new Button();
                        button.ID = "button" + tableid;
                        button.Text = "Show Clashes";
                        button.CommandArgument = tempYear;
                        button.Command += new CommandEventHandler(nextPage);
                        buttonCell.Controls.Add(button);

                        tr.Cells.Add(yearCell);
                        tr.Cells.Add(buttonCell);
                        Table1.Rows.Add(tr);
                        tableid++;
                    }

                   
                }
            }
        }   
    }

    //This is old code
    //This is basic dataset code.
    protected void temporary()
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "select ModuleId, Day, Time from Lecture where LectureId = '1'";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader dr = cmd.ExecuteReader();
        DataSet ds = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter("select ModuleId, Day, Time from Lecture where LectureId = '1'" + "select ModuleId, Day, Time from Lecture where LectureId = '2'", connectionString);
        da.Fill(ds);
        //Label1.Text = ds.Tables[0].Rows[0][2].ToString();
        dr.Close();
        conn.Close();
    }

    //This is old code
    //This is a test version of selectModules(). It contains no parameters.
    protected void selectModules2()
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        
            string sql = "select ModuleId from Module where Year = 'BIS2'";
            conn.Open();
            SqlCommand cmd = new SqlCommand(sql, conn);
            List<String> modules = new List<string>();
            modules.Clear();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                modules.Add(dr["ModuleId"].ToString());
            }
            readLecture(modules);
            lectureTest();
    }

    //Opens YearClashes2
    public void nextPage(object sender, CommandEventArgs e)
    {
        Session["String"] = e.CommandArgument.ToString(); //This will be used in YearClashes2
        Response.Redirect("YearClashes2.aspx");
        
    }

    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/MainMenu.aspx");
    }
}