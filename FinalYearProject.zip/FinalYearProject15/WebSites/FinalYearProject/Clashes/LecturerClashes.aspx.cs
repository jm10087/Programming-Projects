﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Clashes_LecturerClashes : System.Web.UI.Page
{

    Lecturer lecturer;
    String module;
    String room;
    String staffId;
    String day;
    String time;
    int semester;
    List<TableRow> tablerowList = new List<TableRow>();
    List<String> moduleID = new List<String>();
    int tableid = 0;
    List<String> moduleIDNew = new List<string>();
    String test;
    String dayString;
    String timeString;
    List<String> staffIdList = new List<string>();
    List<String> lectureID = new List<string>();
    List<int> semesterList = new List<int>();
    List<String> dayList = new List<String>();
    List<String> timeList = new List<String>();
    int tableid2 = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        displayClashes();
    }

    protected void displayClashes()
    {
        try
        {
            //Clears list of module ids
            moduleID.Clear();

            lecturer = new Lecturer();
            //Reads a list of staff ids that are clashing
            lecturer.readLecturerMenu();
            int j = lecturer.countStaffIdList(); //Amount of staff ids that are clashing

            for (int i = 0; i < j; i++)
            {
                staffIdList.Add(lecturer.getStaffIdList(i));
            }

            //Clears table rows
            table1.Rows.Clear();

            //Adds header rows
            TableHeaderRow theadRow = new TableHeaderRow();

            TableHeaderCell theadCellStaff = new TableHeaderCell();
            theadCellStaff.Text = "Staff";
          
            theadRow.Cells.Add(theadCellStaff);

            table1.Rows.Add(theadRow);

            for (int i = 0; i < j; i++)
            {

                staffId = staffIdList[i];

                    TableRow tablerow = new TableRow();
                    tablerow.ID = "tablerow" + tableid.ToString();

                    TableCell tablecellStaffId = new TableCell();
                    tablecellStaffId.Text = staffId;

                    tablerow.Cells.Add(tablecellStaffId);

                    
                    //Adds button to view clashes
                    Button button = new Button();
                    button.ID = "buttonleft" + i.ToString();
                    button.Attributes.Add("runat", "server");
                    button.Text = "View Clashes";
                    button.CommandArgument = staffId;
                    button.Command += new CommandEventHandler(firstButton);

                    TableCell tablecellButton = new TableCell();
                    tablecellButton.Controls.Add(button);

                    tablerow.Cells.Add(tablecellButton);

                    table1.Rows.Add(tablerow);

                    tableid++;

            }
        }
        catch (Exception ex)
        {
            lblError.Text = "Please enter a valid semester or staff number.";
        }
    }

    protected void firstButton(object sender, CommandEventArgs e)
    {
        Session["text"] = e.CommandArgument.ToString(); //To be used to in LecturerClashes2
        //showAllClashes(e.CommandArgument.ToString ());
        Response.Redirect("LecturerClashes2"); //Opens LecturerClashes2
    }

    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/MainMenu.aspx");
    }

    //From here onwards is unused code
    protected void showAllClashes(String LecturerParam)
    {
        lecturer = new Lecturer();
        lecturer.readLecturerCompare(LecturerParam);

        String lectureId;
        String semesterClash;

        int j = lecturer.countLectureIdList();

        for (int i = 0; i < j; i++)
        {
            lectureID.Add(lecturer.getLectureIdList(i));
        }

        TableHeaderRow theadRow = new TableHeaderRow();

        TableHeaderCell theadCellSemester = new TableHeaderCell();
        theadCellSemester.Text = "Semester";
        TableHeaderCell theadCellDay = new TableHeaderCell();
        theadCellDay.Text = "Day";
        TableHeaderCell theadCellTime = new TableHeaderCell();
        theadCellTime.Text = "Time";

        theadRow.Cells.Add(theadCellSemester);
        theadRow.Cells.Add(theadCellDay);
        theadRow.Cells.Add(theadCellTime);

        table2.Rows.Add(theadRow);

        int test = 0;

        for (int i = 0; i < j; i++)
        {

            lectureId = lectureID[i];

            lecturer.readLecturerModules(lectureId);

            semesterClash = lecturer.getSemester().ToString();
            //setDay(lecturer.getDay());
            //setTime(lecturer.getTime());
            String day1 = lecturer.getDay();
            String time1 = lecturer.getTime();

            for (int l = 0; l < semesterList.Count; l++) 
            {
                if (semesterClash == semesterList[l].ToString() && dayString == dayList[l] && timeString == timeList[l])
                {
                    test = 1;
                }
                else
                {
                    test = 0;
                }
            }

            if (test == 0)
            {
                semesterList.Add(lecturer.getSemester());
                dayList.Add(dayString);
                timeList.Add(timeString);

                TableRow tablerow = new TableRow();
                tablerow.ID = "tablerow" + tableid2.ToString();

                TableCell semesterCell = new TableCell();
                semesterCell.Text = semesterClash;
                semesterCell.HorizontalAlign = HorizontalAlign.Center;
                tablerow.Cells.Add(semesterCell);

                TableCell dayCell = new TableCell();
                dayCell.Text = day1;
                tablerow.Cells.Add(dayCell);

                TableCell timeCell = new TableCell();
                timeCell.Text = time1;
                tablerow.Cells.Add(timeCell);

                Button button = new Button();
                button.ID = "buttonleft" + i.ToString();
                button.Attributes.Add("runat", "server");
                button.Text = "View Clashes";
                button.CommandArgument = LecturerParam + "," + lecturer.getSemester().ToString() + "." + lecturer.getDay().ToString() + "/" + lecturer.getTime().ToString();
                //button.Command += new CommandEventHandler(example);

                TableCell tablecellButton = new TableCell();
                tablecellButton.Controls.Add(button);

                tablerow.Cells.Add(tablecellButton);

                table2.Rows.Add(tablerow);

                table2.Visible = true;

                tableid2++;
            }

            

           // if (newRows.Count > 0)
            //{
              //  foreach (TableRow dr in newRows)
                //{
                  //  table2.Rows.Add(dr);
                //}

               

           // }

        }

    }

    protected void setDay(int a)
    {
        switch (a)
        {
            case 1:
                dayString = "Monday";
                break;

            case 2:
                dayString = "Tuesday";
                break;

            case 3:
                dayString = "Wednesday";
                break;

            case 4:
                dayString = "Thursday";
                break;

            case 5:
                dayString = "Friday";
                break;

            case 6:
                dayString = "Saturday";
                break;

            case 7:
                dayString = "Sunday";
                break;
        }
    }

    protected void setTime(int a)
    {
        switch (a)
        {
            case 1:
                timeString = "8:00 - 9:00";
                break;

            case 2:
                timeString = "9:00 - 10:00";
                break;

            case 3:
                timeString = "10:00 - 11:00";
                break;

            case 4:
                timeString = "11:00- 12:00";
                break;

            case 5:
                timeString = "12:00 - 13:00";
                break;

            case 6:
                timeString = "13:00 - 14:00";
                break;

            case 7:
                timeString = "14:00 - 15:00";
                break;

            case 8:
                timeString = "15:00 - 16:00";
                break;

            case 9:
                timeString = "16:00 - 17:00";
                break;

            case 10:
                timeString = "17:00 - 18:00";
                break;

            case 11:
                timeString = "18:00 - 19:00";
                break;
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        //displayClashes();
    }

    public void secondButton(object sender, CommandEventArgs e)
    {
        char[] delimiterChars = { ',', '.', '/'};
        String s = e.CommandArgument.ToString();

        String[] t = s.Split(delimiterChars);
        //selectLecturerModules(t[0], Convert.ToInt32(t[1]), Convert.ToInt32(t[2]), Convert.ToInt32(t[3]));
    }
    
    public void selectLecturerModules(String lecturerParam, int semesterParam, String dayParam, String timeParam) 
    {
        //try
        //{

        moduleID.Clear();

        lecturer = new Lecturer();
        lecturer.readLecturerFinal(lecturerParam, semesterParam, dayParam, timeParam);
        int j = lecturer.countLectureIdList();

        for (int i = 0; i < j; i++)
        {
            lectureID.Add(lecturer.getLectureIdList(i));
        }

        Table3.Rows.Clear();

        TableHeaderRow theadRow = new TableHeaderRow();

        TableHeaderCell theadCellModule = new TableHeaderCell();
        theadCellModule.Text = "Module";
        TableHeaderCell theadCellSemester = new TableHeaderCell();
        theadCellSemester.Text = "Semester";
        TableHeaderCell theadCellDay = new TableHeaderCell();
        theadCellDay.Text = "Day";
        TableHeaderCell theadCellTime = new TableHeaderCell();
        theadCellTime.Text = "Time";

        theadRow.Cells.Add(theadCellModule);
        theadRow.Cells.Add(theadCellSemester);
        theadRow.Cells.Add(theadCellDay);
        theadRow.Cells.Add(theadCellTime);

        Table3.Rows.Add(theadRow);

        for (int i = 0; i < j; i++)
        {

            lecturer.readLecturerFinal2(lectureID[i]);

            module = lecturer.getModule();
            semester = lecturer.getSemester();
            day = lecturer.getDay();
            //setDay(day);
            time = lecturer.getTime();
            //setTime(time);

            TableRow tablerow = new TableRow();
            tablerow.ID = "tablerow" + tableid.ToString();

            TableCell tableCellModule = new TableCell();
            tableCellModule.Text = module;
            TableCell tableCellSemester = new TableCell();
            tableCellSemester.Text = semester.ToString();
            tableCellSemester.HorizontalAlign = HorizontalAlign.Center;
            TableCell tableCellDay = new TableCell();
            tableCellDay.Text = day;
            TableCell tableCellTime = new TableCell();
            tableCellTime.Text = time;

            tablerow.Cells.Add(tableCellModule);
            tablerow.Cells.Add(tableCellSemester);
            tablerow.Cells.Add(tableCellDay);
            tablerow.Cells.Add(tableCellTime);

            Button button = new Button();
            button.ID = "buttonleft" + i.ToString();
            button.Attributes.Add("runat", "server");
            button.Text = "Remove";
            button.CommandArgument = lectureID[i];
            button.Command += new CommandEventHandler(firstButton);

            TableCell tablecellButton = new TableCell();
            tablecellButton.Controls.Add(button);

            tablerow.Cells.Add(tablecellButton);

            Table3.Rows.Add(tablerow);

            tableid++;

        }
        //}
        //catch (Exception ex)
        //{
        //  lblError.Text = "Please enter a valid semester or staff number.";
        //}
    }

  
}