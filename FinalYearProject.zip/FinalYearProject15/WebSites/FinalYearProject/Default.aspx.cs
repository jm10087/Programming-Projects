﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : Page
{

    protected void Page_Load(object sender, EventArgs e)
    {

    }


    //This determines if the user has the correct username and password to log into the system
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        try
        {
            String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
            //SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=database;Integrated Security=True;MultipleActiveResultSets=True");
            SqlConnection conn = new SqlConnection(connectionString);
            string sql = "select UserId, Password from [User] where UserId = @UserId and Password = @Password";
            //string sql = "select ModuleId from Lecture";
            conn.Open();
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@UserId", txtUser.Text);
            cmd.Parameters.AddWithValue("@Password", txtPass.Text);
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                Response.Redirect("MainMenu.aspx");
            }
            else
            {
                lblError.Text = "Invalid username or password";
            }
            dr.Close();
            conn.Close();
        }
        catch
        {
            LabelError.Text = "SQL Server database not found.";
        }
    }
}