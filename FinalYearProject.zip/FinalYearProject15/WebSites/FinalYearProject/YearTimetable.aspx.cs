﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class YearTimetable : System.Web.UI.Page
{

    Year year;
    Room room;
    String module;
    String module2;
    String yearId;
    String staffId;
    String day;
    String time;
    int semester;
    List<String> moduleID = new List<String>();
    List<String> YearIdList = new List<string>();
    Button button = new Button();

    

    protected void Page_Load(object sender, EventArgs e)
    {
        //button.Click += new EventHandler(this.test);
        //YearName.Controls.Add(button);


        //Populates dropdown boxes with semesters and course years
        if (!Page.IsPostBack)
        {
            DropDownSemester.Items.Add("1");
            DropDownSemester.Items.Add("2");
            DropDownSemester.DataBind();
            DropDownSemester.SelectedIndex = 0;

            Year year = new Year();
            year.readYearFromYearTable();
            int j = year.countYearIdList();

            for (int i = 0; i < j; i++)
            {
                YearIdList.Add(year.getYearIdList(i));
            }

            DropDownYear.DataSource = YearIdList;
            DropDownYear.DataBind();
            DropDownYear.SelectedIndex = 0;
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //try
        //{
            //Makes cells null
            makeNull();
           

           
            semester = Int32.Parse(DropDownSemester.SelectedValue.Trim());

            year = new Year();
            yearId = DropDownYear.SelectedValue.Trim();

            //Reads the amount of modules of a certain year
            year.readModules(yearId);
            int j = year.getModuleCount();

            //Adds all module ids of the year to an array
            for (int i = 0; i < j; i++)
            {
                moduleID.Add(year.getModuleID(i));
            }

            for (int i = 0; i < j; i++)
            {
                //Reads data for the specified module id and semester. Loops for all module ids in the year.
                year.numberOfLectures(semester, moduleID[i]);
                module2 = moduleID[i];

                int k = year.getLectureCount();

                
                //Reads all lectures for a particular year and obatins data for them
                for (int m = 0; m < k; m++)
                {

                
                    year.readYear(semester, module2, m);

                    module = year.getModule();
                    //staffId = year.getStaff();
                    day = year.getDay();
                    time = year.getTime();
             

                    if (module != null)
                    {
                        YearName.Text = "Year ID: " + yearId;
                        populateTimetable(module, staffId, day, time); //Populates the timetable with data
                        lblError.Text = "";
                    }
                    else
                    {
                        lblError.Text = "The selected year has no lectures this semester.";
                    }
                }
            }
            //}
            //catch (Exception)
            //{
              //lblError.Text = "Please enter a valid year or semester.";
            //}
        }
    
    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("MainMenu.aspx");
    }
     public void makeNull()
    {
        Mon8to9.Text = null;
        Mon9to10.Text = null;
        Mon10to11.Text = null;
        Mon11to12.Text = null;
        Mon12to13.Text = null;
        Mon13to14.Text = null;
        Mon14to15.Text = null;
        Mon15to16.Text = null;
        Mon16to17.Text = null;
        Mon17to18.Text = null;
        Mon18to19.Text = null;

        Tue8to9.Text = null;
        Tue9to10.Text = null;
        Tue10to11.Text = null;
        Tue12to13.Text = null;
        Tue13to14.Text = null;
        Tue14to15.Text = null;
        Tue15to16.Text = null;
        Tue16to17.Text = null;
        Tue17to18.Text = null;
        Tue18to19.Text = null;

        Wed8to9.Text = null;
        Wed9to10.Text = null;
        Wed10to11.Text = null;
        Wed11to12.Text = null;
        Wed12to13.Text = null;
        Wed13to14.Text = null;
        Wed14to15.Text = null;
        Wed15to16.Text = null;
        Wed16to17.Text = null;
        Wed17to18.Text = null;
        Wed18to19.Text = null;

        Thu8to9.Text = null;
        Thu9to10.Text = null;
        Thu10to11.Text = null;
        Thu11to12.Text = null;
        Thu12to13.Text = null;
        Thu13to14.Text = null;
        Thu14to15.Text = null;
        Thu15to16.Text = null;
        Thu16to17.Text = null;
        Thu17to18.Text = null;
        Thu18to19.Text = null;

        Fri8to9.Text = null;
        Fri9to10.Text = null;
        Fri10to11.Text = null;
        Fri11to12.Text = null;
        Fri12to13.Text = null;
        Fri13to14.Text = null;
        Fri14to15.Text = null;
        Fri15to16.Text = null;
        Fri16to17.Text = null;
        Fri17to18.Text = null;
        Fri18to19.Text = null;
    }

    //Earlier version of the below method
     public void populateTimetable1(String module, String room, int day, int time)
    {
        switch (day)
        {
            case 1:
                switch (time)
                {
                    case 1:
                        Mon8to9.Text = module + "<br/>" + room;
                        break;
                    case 2:
                        Mon9to10.Text = module + "<br/>" + room;
                        break;
                    case 3:
                        Mon10to11.Text = module + "<br/>" + room;
                        break;
                    case 4:
                        Mon11to12.Text = module + "<br/>" + room;
                        break;
                    case 5:
                        Mon12to13.Text = module + "<br/>" + room;
                        break;
                    case 6:
                        Mon13to14.Text = module + "<br/>" + room;
                        break;
                    case 7:
                        Mon14to15.Text = module + "<br/>" + room;
                        break;
                    case 8:
                        Mon15to16.Text = module + "<br/>" + room;
                        break;
                    case 9:
                        Mon16to17.Text = module + "<br/>" + room;
                        break;
                    case 10:
                        Mon17to18.Text = module + "<br/>" + room;
                        break;
                    case 11:
                        Mon18to19.Text = module + "<br/>" + room;
                        break;
                }
                break;

            case 2:
                switch (time)
                {
                    case 1:
                        Tue8to9.Text = module + "<br/>" + room;
                        break;
                    case 2:
                        Tue9to10.Text = module + "<br/>" + room;
                        break;
                    case 3:
                        Tue10to11.Text = module + "<br/>" + room;
                        break;
                    case 4:
                        Tue11to12.Text = module + "<br/>" + room;
                        break;
                    case 5:
                        Tue12to13.Text = module + "<br/>" + room;
                        break;
                    case 6:
                        Tue13to14.Text = module + "<br/>" + room;
                        break;
                    case 7:
                        Tue14to15.Text = module + "<br/>" + room;
                        break;
                    case 8:
                        Tue15to16.Text = module + "<br/>" + room;
                        break;
                    case 9:
                        Tue16to17.Text = module + "<br/>" + room;
                        break;
                    case 10:
                        Tue17to18.Text = module + "<br/>" + room;
                        break;
                    case 11:
                        Tue18to19.Text = module + "<br/>" + room;
                        break;
                }
                break;

            case 3:
                switch (time)
                {
                    case 1:
                        Wed8to9.Text = module + "<br/>" + room;
                        break;
                    case 2:
                        Wed9to10.Text = module + "<br/>" + room;
                        break;
                    case 3:
                        Wed10to11.Text = module + "<br/>" + room;
                        break;
                    case 4:
                        Wed11to12.Text = module + "<br/>" + room;
                        break;
                    case 5:
                        Wed12to13.Text = module + "<br/>" + room;
                        break;
                    case 6:
                        Wed13to14.Text = module + "<br/>" + room;
                        break;
                    case 7:
                        Wed14to15.Text = module + "<br/>" + room;
                        break;
                    case 8:
                        Wed15to16.Text = module + "<br/>" + room;
                        break;
                    case 9:
                        Wed16to17.Text = module + "<br/>" + room;
                        break;
                    case 10:
                        Wed17to18.Text = module + "<br/>" + room;
                        break;
                    case 11:
                        Wed18to19.Text = module + "<br/>" + room;
                        break;
                }
                break;

            case 4:
                switch (time)
                {
                    case 1:
                        Thu8to9.Text = module + "<br/>" + room;
                        break;
                    case 2:
                        Thu9to10.Text = module + "<br/>" + room;
                        break;
                    case 3:
                        Thu10to11.Text = module + "<br/>" + room;
                        break;
                    case 4:
                        Thu11to12.Text = module + "<br/>" + room;
                        break;
                    case 5:
                        Thu12to13.Text = module + "<br/>" + room;
                        break;
                    case 6:
                        Thu13to14.Text = module + "<br/>" + room;
                        break;
                    case 7:
                        Thu14to15.Text = module + "<br/>" + room;
                        break;
                    case 8:
                        Thu15to16.Text = module + "<br/>" + room;
                        break;
                    case 9:
                        Thu16to17.Text = module + "<br/>" + room;
                        break;
                    case 10:
                        Thu17to18.Text = module + "<br/>" + room;
                        break;
                    case 11:
                        Thu18to19.Text = module + "<br/>" + room;
                        break;
                }
                break;

            case 5:
                switch (time)
                {
                    case 1:
                        Fri8to9.Text = module + "<br/>" + room;
                        break;
                    case 2:
                        Fri9to10.Text = module + "<br/>" + room;
                        break;
                    case 3:
                        Fri10to11.Text = module + "<br/>" + room;
                        break;
                    case 4:
                        Fri11to12.Text = module + "<br/>" + room;
                        break;
                    case 5:
                        Fri12to13.Text = module + "<br/>" + room;
                        break;
                    case 6:
                        Fri13to14.Text = module + "<br/>" + room;
                        break;
                    case 7:
                        Fri14to15.Text = module + "<br/>" + room;
                        break;
                    case 8:
                        Fri15to16.Text = module + "<br/>" + room;
                        break;
                    case 9:
                        Fri16to17.Text = module + "<br/>" + room;
                        break;
                    case 10:
                        Fri17to18.Text = module + "<br/>" + room;
                        break;
                    case 11:
                        Fri18to19.Text = module + "<br/>" + room;
                        break;
                }
                break;
        }
    }

     public void test(object sender, EventArgs e)
     {
         Response.Redirect("MainMenu.aspx");
     }

    //Populates the timetable based on data read
     public void populateTimetable(String module, String room, String day, String time)
     {
         if (day == "Monday" && time == "8:00-9:00")
         {
             Mon8to9.Text = module + "<br/>" + room;
         }
         else if (day == "Monday" && time == "9:00-10:00")
         {
             Mon9to10.Text = module + "<br/>" + room;
         }
         else if (day == "Monday" && time == "10:00-11:00")
         {
             Mon10to11.Text = module + "<br/>" + room;
         }
         else if (day == "Monday" && time == "11:00-12:00")
         {
             Mon11to12.Text = module + "<br/>" + room;
         }
         else if (day == "Monday" && time == "12:00-13:00")
         {
             Mon12to13.Text = module + "<br/>" + room;
         }
         else if (day == "Monday" && time == "13:00-14:00")
         {
             Mon13to14.Text = module + "<br/>" + room;
         }
         else if (day == "Monday" && time == "14:00-15:00")
         {
             Mon14to15.Text = module + "<br/>" + room;
         }
         else if (day == "Monday" && time == "15:00-16:00")
         {
             Mon15to16.Text = module + "<br/>" + room;
         }
         else if (day == "Monday" && time == "16:00-17:00")
         {
             Mon16to17.Text = module + "<br/>" + room;
         }
         else if (day == "Monday" && time == "17:00-18:00")
         {
             Mon17to18.Text = module + "<br/>" + room;
         }
         else if (day == "Monday" && time == "18:00-19:00")
         {
             Mon18to19.Text = module + "<br/>" + room;
         }

         else if (day == "Tuesday" && time == "8:00-9:00")
         {
             Tue8to9.Text = module + "<br/>" + room;
         }
         else if (day == "Tuesday" && time == "9:00-10:00")
         {
             Tue9to10.Text = module + "<br/>" + room;
         }
         else if (day == "Tuesday" && time == "10:00-11:00")
         {
             Tue10to11.Text = module + "<br/>" + room;
         }
         else if (day == "Tuesday" && time == "11:00-12:00")
         {
             Tue11to12.Text = module + "<br/>" + room;
         }
         else if (day == "Tuesday" && time == "12:00-13:00")
         {
             Tue12to13.Text = module + "<br/>" + room;
         }
         else if (day == "Tuesday" && time == "13:00-14:00")
         {
             Tue13to14.Text = module + "<br/>" + room;
         }
         else if (day == "Tuesday" && time == "14:00-15:00")
         {
             Tue14to15.Text = module + "<br/>" + room;
         }
         else if (day == "Tuesday" && time == "15:00-16:00")
         {
             Tue15to16.Text = module + "<br/>" + room;
         }
         else if (day == "Tuesday" && time == "16:00-17:00")
         {
             Tue16to17.Text = module + "<br/>" + room;
         }
         else if (day == "Tuesday" && time == "17:00-18:00")
         {
             Tue17to18.Text = module + "<br/>" + room;
         }
         else if (day == "Tuesday" && time == "18:00-19:00")
         {
             Tue18to19.Text = module + "<br/>" + room;
         }

         else if (day == "Wednesday" && time == "8:00-9:00")
         {
             Wed8to9.Text = module + "<br/>" + room;
         }
         else if (day == "Wednesday" && time == "9:00-10:00")
         {
             Wed9to10.Text = module + "<br/>" + room;
         }
         else if (day == "Wednesday" && time == "10:00-11:00")
         {
             Wed10to11.Text = module + "<br/>" + room;
         }
         else if (day == "Wednesday" && time == "11:00-12:00")
         {
             Wed11to12.Text = module + "<br/>" + room;
         }
         else if (day == "Wednesday" && time == "12:00-13:00")
         {
             Wed12to13.Text = module + "<br/>" + room;
         }
         else if (day == "Wednesday" && time == "13:00-14:00")
         {
             Wed13to14.Text = module + "<br/>" + room;
         }
         else if (day == "Wednesday" && time == "14:00-15:00")
         {
             Wed14to15.Text = module + "<br/>" + room;
         }
         else if (day == "Wednesday" && time == "15:00-16:00")
         {
             Wed15to16.Text = module + "<br/>" + room;
         }
         else if (day == "Wednesday" && time == "16:00-17:00")
         {
             Wed16to17.Text = module + "<br/>" + room;
         }
         else if (day == "Wednesday" && time == "17:00-18:00")
         {
             Wed17to18.Text = module + "<br/>" + room;
         }
         else if (day == "Wednesday" && time == "18:00-19:00")
         {
             Wed18to19.Text = module + "<br/>" + room;
         }


         else if (day == "Thursday" && time == "8:00-9:00")
         {
             Thu8to9.Text = module + "<br/>" + room;
         }
         else if (day == "Thursday" && time == "9:00-10:00")
         {
             Thu9to10.Text = module + "<br/>" + room;
         }
         else if (day == "Thursday" && time == "10:00-11:00")
         {
             Thu10to11.Text = module + "<br/>" + room;
         }
         else if (day == "Thursday" && time == "11:00-12:00")
         {
             Thu11to12.Text = module + "<br/>" + room;
         }
         else if (day == "Thursday" && time == "12:00-13:00")
         {
             Thu12to13.Text = module + "<br/>" + room;
         }
         else if (day == "Thursday" && time == "13:00-14:00")
         {
             Thu13to14.Text = module + "<br/>" + room;
         }
         else if (day == "Thursday" && time == "14:00-15:00")
         {
             Thu14to15.Text = module + "<br/>" + room;
         }
         else if (day == "Thursday" && time == "15:00-16:00")
         {
             Thu15to16.Text = module + "<br/>" + room;
         }
         else if (day == "Thursday" && time == "16:00-17:00")
         {
             Thu16to17.Text = module + "<br/>" + room;
         }
         else if (day == "Thursday" && time == "17:00-18:00")
         {
             Thu17to18.Text = module + "<br/>" + room;
         }
         else if (day == "Thursday" && time == "18:00-19:00")
         {
             Thu18to19.Text = module + "<br/>" + room;
         }


         else if (day == "Friday" && time == "8:00-9:00")
         {
             Fri8to9.Text = module + "<br/>" + room;
         }
         else if (day == "Friday" && time == "9:00-10:00")
         {
             Fri9to10.Text = module + "<br/>" + room;
         }
         else if (day == "Friday" && time == "10:00-11:00")
         {
             Fri10to11.Text = module + "<br/>" + room;
         }
         else if (day == "Friday" && time == "11:00-12:00")
         {
             Fri11to12.Text = module + "<br/>" + room;
         }
         else if (day == "Friday" && time == "12:00-13:00")
         {
             Fri12to13.Text = module + "<br/>" + room;
         }
         else if (day == "Friday" && time == "13:00-14:00")
         {
             Fri13to14.Text = module + "<br/>" + room;
         }
         else if (day == "Friday" && time == "14:00-15:00")
         {
             Fri14to15.Text = module + "<br/>" + room;
         }
         else if (day == "Friday" && time == "15:00-16:00")
         {
             Fri15to16.Text = module + "<br/>" + room;
         }
         else if (day == "Friday" && time == "16:00-17:00")
         {
             Fri16to17.Text = module + "<br/>" + room;
         }
         else if (day == "Friday" && time == "17:00-18:00")
         {
             Fri17to18.Text = module + "<br/>" + room;
         }
         else if (day == "Friday" && time == "18:00-19:00")
         {
             Fri18to19.Text = module + "<br/>" + room;
         }
     }
   
}