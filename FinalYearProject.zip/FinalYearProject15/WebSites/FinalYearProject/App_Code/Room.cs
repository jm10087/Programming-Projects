﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Web.Configuration;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Room
/// </summary>
public class Room
{

    String roomID;
    String buildingID;
    List<String> moduleID = new List<String>();
    List<String> moduleIDNew = new List<String>();
    List<String> LectureID = new List<string>();
    List<String> RoomIdList2 = new List<string>();
    List<String> RoomIdList = new List<string>();
    List<String> RoomID = new List<string>();
    String module;
    String staffId;
    String day;
    String time;
    int Semester;
    String LectureId;
    String yearId;
    String week;

    public Room()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    //Read the amount of lectures associated with a particular room in a certain semester
    public void readRoomTest(int x, String y)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        //SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=database;Integrated Security=True;MultipleActiveResultSets=True");
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "select ModuleId from Lecture where SemesterId = @SemesterId and RoomId = @RoomId";
        //string sql = "select ModuleId from Lecture";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@SemesterId", x);
        cmd.Parameters.AddWithValue("@RoomId", y);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {

            moduleID.Add(dr["ModuleId"].ToString());
        }
        dr.Close();
        conn.Close();
    }

    //Reads the data associated with a particular room incrementally in a certain semester
    public void readRoom(int x, String y, int z)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        //SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=database;Integrated Security=True;MultipleActiveResultSets=True");
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "With test as (select ModuleId, StaffId, Day, Time, ROW_NUMBER() over (order by ModuleID) as rowNumber from Lecture where SemesterId = @SemesterId and RoomId = @RoomId)select ModuleId, StaffId, Day, Time, rowNumber from test where rowNumber > @RowNumber";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@SemesterId", x);
        cmd.Parameters.AddWithValue("@RoomId", y);
        cmd.Parameters.AddWithValue("@RowNumber", z);
        SqlDataReader dr = cmd.ExecuteReader();
        // int i = 0;
        while (dr.Read())
        {
            module = dr["ModuleId"].ToString();
            //moduleID.Add(dr["ModuleID"].ToString());
            if (!dr.IsDBNull(dr.GetOrdinal("StaffId")))
            {
                staffId = dr["StaffId"].ToString();
            }
            else
            {
                staffId = "null";
            }
            staffId  = dr["StaffId"].ToString();
            //day.Add(Convert.ToInt32(dr["Day"]));
            if (!dr.IsDBNull(dr.GetOrdinal("Day")))
            {
                day = dr["Day"].ToString().Trim();
            }
            else
            {
                day = "0";
            }

            if (!dr.IsDBNull(dr.GetOrdinal("Time")))
            {
                time = dr["Time"].ToString().Trim();
            }
            else
            {
                time = "0";
            }
            //i++;
            break;

        }
        dr.Close();
        conn.Close();
    }

    //This selects every ModuleId in the Module table
    public void readModules()
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        //SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=database;Integrated Security=True;MultipleActiveResultSets=True");
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "select ModuleId from Module";
        //string sql = "select ModuleId from Lecture";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {

            moduleIDNew.Add(dr["ModuleId"].ToString());
            module = dr["ModuleId"].ToString();
        }
        dr.Close();
        conn.Close();
    }

    //This writes a new lecture assigned to a particular room
    public void writeRoom(String module, String roomId)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Insert into Lecture (ModuleId, RoomId) values(@ModuleId, @RoomId)";
        //string sql2 = "select ModuleId from Lecture where ModuleId = '" + module + "'and StaffId = '" + lecturerId + "'";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        //SqlCommand cmd2 = new SqlCommand(sql2, conn);

        cmd.Parameters.AddWithValue("@ModuleId", module);
        cmd.Parameters.AddWithValue("@RoomId", roomId);

        //SqlDataReader dr = cmd2.ExecuteReader ();

        //if (dr.HasRows)
        //{

        //}
        //else
        //{

        //}


        cmd.ExecuteNonQuery();
        conn.Close();
    }

    //This deletes a particular lecture
    public void deleteModule(String moduleId, String RoomId, int semester, String day, String time)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();
        SqlCommand cmd = new SqlCommand("Update Lecture set RoomId = null where ModuleId = @ModuleId and RoomId = @RoomId and SemesterId =@semester and Day =  @day and time = @time", conn);
        cmd.Parameters.AddWithValue("@ModuleId", moduleId);
        cmd.Parameters.AddWithValue("@RoomId", RoomId);
        cmd.Parameters.AddWithValue("@semester", semester);
        cmd.Parameters.AddWithValue("@day", day);
        cmd.Parameters.AddWithValue("@time", time);
        cmd.ExecuteNonQuery();
        conn.Close();
    }

    //Selects all lectures belonging to a particular room, regardless of semester
    public void readRoomTestSave(String y)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        //SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=database;Integrated Security=True;MultipleActiveResultSets=True");
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "select ModuleId from Lecture where RoomId = @RoomId";
        //string sql = "select ModuleId from Lecture";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@RoomId", y);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            moduleID.Add(dr["ModuleId"].ToString());
        }
        dr.Close();
        conn.Close();
    }

    //Reads data pertaining to a specified lecture of a room
    public void readRoomSave(String y, int z)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        //SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=database;Integrated Security=True;MultipleActiveResultSets=True");
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "With test as (select LectureId, ModuleId, RoomId, SemesterId, Day, Time, Week, ROW_NUMBER() over (order by ModuleID) as rowNumber from Lecture where RoomId = @RoomId)select LectureId, ModuleId, RoomId, SemesterId, Day, Time, Week, rowNumber from test where rowNumber > @RowNumber";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@RoomId", y);
        cmd.Parameters.AddWithValue("@RowNumber", z);
        SqlDataReader dr = cmd.ExecuteReader();
        // int i = 0;
        while (dr.Read())
        {
            LectureId = dr["LectureId"].ToString();
            module = dr["ModuleId"].ToString();
            //moduleID.Add(dr["ModuleID"].ToString());
            //room = dr["RoomId"].ToString();
            //day.Add(Convert.ToInt32(dr["Day"]));
            if (!dr.IsDBNull(dr.GetOrdinal("Day")))
            {
                day = dr["Day"].ToString().Trim();
            }
            else
            {
                day = "0";
            }

            if (!dr.IsDBNull(dr.GetOrdinal("Time")))
            {
                time = dr["Time"].ToString().Trim();
            }
            else
            {
                time = "0";
            }

            if (!dr.IsDBNull(dr.GetOrdinal("Week")))
            {
                week = dr["Week"].ToString().Trim();
            }
            else
            {
                week = "0";
            }

            if (!dr.IsDBNull(dr.GetOrdinal("SemesterId")))
            {
                Semester = Convert.ToInt32(dr["SemesterId"]);
            }
            else
            {
                Semester = 0;
            }
            //i++;
            break;



        }
        dr.Close();
        conn.Close();
    }

    //Selects all lectures of the selected room and checks for clashes
    public void readRoomCompare(String Room)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select LectureId, SemesterId, Day, Time from Lecture where RoomId = @RoomId";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@RoomId", Room);
        SqlDataReader dr = cmd.ExecuteReader();
        roomID = Room;
        
        while (dr.Read())
        {
            LectureId = dr["LectureId"].ToString();
            if (!dr.IsDBNull(dr.GetOrdinal("Day")))
            {
                day = dr["Day"].ToString().Trim();
            }
            else
            {
                day = "0";
            }

            if (!dr.IsDBNull(dr.GetOrdinal("Time")))
            {
                time = dr["Time"].ToString().Trim();
            }
            else
            {
                time = "0";
            }

            if (!dr.IsDBNull(dr.GetOrdinal("SemesterId")))
            {
                Semester = Convert.ToInt32(dr["SemesterId"]);
            }
            else
            {
                Semester = 0;
            }
            readRoomCompare2(Room, day, time, Semester, LectureId);
        }
        dr.Close();
        conn.Close();
    }

    //Checks for clashes and adds the lecture ids of those lectures that are clashing
    public void readRoomCompare2(String Room, String day, String time, int semester, String lectureId)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select SemesterId, Day, Time from Lecture where RoomId = @RoomId and Day = @day and Time = @time and SemesterId = @semester and LectureId != @lectureId";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@LectureId", lectureId);
        cmd.Parameters.AddWithValue("@RoomId", Room);
        cmd.Parameters.AddWithValue("@semester", semester);
        cmd.Parameters.AddWithValue("@day", day);
        cmd.Parameters.AddWithValue("@time", time);
        SqlDataReader dr = cmd.ExecuteReader();
        roomID = Room;
        if (dr.HasRows)
        {
            LectureID.Add(lectureId);
        }
        dr.Close();
        conn.Close();
    }

    //Reads all lectures to see if they are clashing
    public void readRoomMenu()
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select LectureId, RoomId, SemesterId, Day, Time from Lecture where len(RoomId) > 1";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader dr = cmd.ExecuteReader();
        String LectureId;
        while (dr.Read())
        {
            if (!dr.IsDBNull(dr.GetOrdinal("RoomId")))
            {
                roomID = dr["RoomId"].ToString();
            }
            else
            {
                roomID = "null";
            }
            
            LectureId = dr["LectureId"].ToString();
            if (!dr.IsDBNull(dr.GetOrdinal("Day")))
            {
                day = dr["Day"].ToString().Trim();
            }
            else
            {
                day = "0";
            }

            if (!dr.IsDBNull(dr.GetOrdinal("Time")))
            {
                time = dr["Time"].ToString().Trim();
            }
            else
            {
                time = "0";
            }

            if (!dr.IsDBNull(dr.GetOrdinal("SemesterId")))
            {
                Semester = Convert.ToInt32(dr["SemesterId"]);
            }
            else
            {
                Semester = 0;
            }

            if (roomID != "null")
            {


                if (!RoomIdList.Contains(roomID))
                {
                    //RoomIdList2.Add(roomID);
                    int i = readRoomMenu2(roomID, day, time, Semester, LectureId);
                    if (i == 1)
                    {
                        RoomIdList.Add(roomID);
                    }
                }
            }
        }
        dr.Close();
        conn.Close();
    }

    //Checks for clashes in room timetable
    public int readRoomMenu2(String Room, String day, String time, int semester, String lectureId)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select SemesterId, Day, Time from Lecture where RoomId = @RoomId and Day = @day and Time = @time and SemesterId = @semester and LectureId != @lectureId";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@LectureId", lectureId);
        cmd.Parameters.AddWithValue("@RoomId", Room);
        cmd.Parameters.AddWithValue("@semester", semester);
        cmd.Parameters.AddWithValue("@day", day);
        cmd.Parameters.AddWithValue("@time", time);
        SqlDataReader dr = cmd.ExecuteReader();
        roomID = Room;
        if (dr.HasRows)
        {
            dr.Close();
            conn.Close();
            return 1;
        }
        else
        {
            dr.Close();
            conn.Close();
            return 0;
        }
    }

    //Reads lecture of a room at a particular time
    public void readRoomFinal(String Room, int semester, String day, String time)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select LectureId from Lecture where RoomId = @RoomId and SemesterId = @semester and Day = @day and Time = @time";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@RoomId", Room);
        cmd.Parameters.AddWithValue("@semester", semester);
        cmd.Parameters.AddWithValue("@day", day);
        cmd.Parameters.AddWithValue("@time", time);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            LectureID.Add(dr["LectureId"].ToString());
        }
        dr.Close();
        conn.Close();
    }

    public void readRoomModules(String lecture)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select SemesterId, Day, Time from Lecture where LectureId = @LectureId";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@LectureId", lecture);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            if (!dr.IsDBNull(dr.GetOrdinal("Day")))
            {
                day = dr["Day"].ToString().Trim();
            }
            else
            {
                day = "0";
            }

            if (!dr.IsDBNull(dr.GetOrdinal("Time")))
            {
                time = dr["Time"].ToString().Trim();
            }
            else
            {
                time = "0";
            }

            if (!dr.IsDBNull(dr.GetOrdinal("SemesterId")))
            {
                Semester = Convert.ToInt32(dr["SemesterId"]);
            }
            else
            {
                Semester = 0;
            }
        }
        dr.Close();
        conn.Close();
    }

    //Selects moduleId day, time, week and semester of a particular lecture
    public void readRoomFinal2(String LectureId)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select ModuleId, SemesterId, Day, Time, Week from Lecture where LectureId = @LectureId";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@LectureId", LectureId);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            module = dr["ModuleId"].ToString();

            if (!dr.IsDBNull(dr.GetOrdinal("Day")))
            {
                day = dr["Day"].ToString().Trim();
            }
            else
            {
                day = "0";
            }

            if (!dr.IsDBNull(dr.GetOrdinal("Time")))
            {
                time = dr["Time"].ToString().Trim();
            }
            else
            {
                time = "0";
            }

            if (!dr.IsDBNull(dr.GetOrdinal("SemesterId")))
            {
                Semester = Convert.ToInt32(dr["SemesterId"]);
            }
            else
            {
                Semester = 0;
            }
            if (!dr.IsDBNull(dr.GetOrdinal("Week")))
            {
                week = dr["Week"].ToString().Trim();
            }
            else
            {
                week = "0";
            }
        }
        dr.Close();
        conn.Close();
    }

    //Removes a particular lecture from its room's schedule
    public void deleteModuleClash(String lectureId)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();
        SqlCommand cmd = new SqlCommand("Update Lecture set RoomId = null where LectureId = @LectureId", conn);
        cmd.Parameters.AddWithValue("@LectureId", lectureId);
        cmd.ExecuteNonQuery();
        conn.Close();
    }

    //Reads lectures where RoomId is null or blank
    public void readRoomNull()
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select LectureId, ModuleId, SemesterId, Day, Time from Lecture where RoomId is null or RoomId = ''";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            LectureID.Add(dr["LectureId"].ToString());
        }
        dr.Close();
        conn.Close();
    }

    //Deletes a particular lecture
    public void deleteModuleLectureId(String LectureId)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();
        SqlCommand cmd = new SqlCommand("Update Lecture set RoomId = null where LectureId = @LectureId", conn);
        cmd.Parameters.AddWithValue("@LectureId", LectureId);
        cmd.ExecuteNonQuery();
        conn.Close();
    }

    //Reads all RoomIds in the Lecturer table
    public void readFromRoomTable()
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "select RoomId from Room";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {

            RoomID.Add(dr["RoomId"].ToString());
        }
        dr.Close();
        conn.Close();
    }

    //Sets a RoomId to an unassigned lecture
    public void writeLectureById(String lecture, String roomId)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Update Lecture set RoomId = @RoomId where LectureId = @Lecture";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@RoomId", roomId);
        cmd.Parameters.AddWithValue("@Lecture", lecture);

        cmd.ExecuteNonQuery();
        conn.Close();
    }

    //Deletes a lecture from the Lecture table
    public void deleteEntry(String LectureId)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();
        SqlCommand cmd = new SqlCommand("Delete from Lecture where LectureId = @LectureId", conn);
        cmd.Parameters.AddWithValue("@LectureId", LectureId);
        cmd.ExecuteNonQuery();
        conn.Close();
    }

    //Reads the year of a particular module
    public void readYearFromModule(String ModuleId)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select Year from Module where ModuleId = @ModuleId";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@ModuleId", ModuleId);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            yearId = dr["Year"].ToString();

        }
        dr.Close();
        conn.Close();
    }

    //Getters and Setters

    public String getModule()
    {
        return module;
    }

    public String getStaff()
    {
        return staffId;
    }

    public String getDay()
    {
        return day;
    }

    public String getTime()
    {
        return time;
    }

    public int getModuleCount()
    {
        return moduleID.Count();
    }

    public String getRoomID()
    {
        return roomID;
    }

    public int getModuleNewCount()
    {
        return moduleIDNew.Count();
    }

    public String getModuleIDNew(int i)
    {
        return moduleIDNew[i];
    }

    public int getSemester()
    {
        return Semester;
    }

    public int countRoomIdList()
    {
        return RoomIdList.Count();
    }

    public String getRoomIdList(int i)
    {
        return RoomIdList[i];
    }

    public int countLectureIdList()
    {
        return LectureID.Count();
    }

    public String getLectureIdList(int i)
    {
        return LectureID[i];
    }

    public String getLectureId()
    {
        return LectureId;
    }

    public int getRoomNullIdCount()
    {
        return RoomID.Count();
    }

    public String getRoomNullIdList(int i)
    {
        return RoomID[i];
    }

    public String getYear()
    {
        return yearId;
    }

    public String getWeek()
    {
        return week;
    }

}