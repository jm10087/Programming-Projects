﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;

/// <summary>
/// Summary description for Year
/// </summary>
public class Year
{

    String yearId;
    String module;
    String room;
    String week;
    String day;
    String time;
    int semester;
    List<String> moduleID = new List<String>();
    List<String> lectures = new List<String>();
    List<String> LectureID = new List<String>();
    List<String> yearIdList = new List<string>();

	public Year()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    //Reads all modules of a particular year
    public void readModules(String y)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        //SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=database;Integrated Security=True;MultipleActiveResultSets=True");
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "select ModuleId from Module where Year = @Year";
        //string sql = "select ModuleId from Lecture";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@Year", y);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {

            moduleID.Add(dr["ModuleId"].ToString());
        }
        dr.Close();
        conn.Close();
    }

    //Reads data of a certain module id for a particular semester
    public void numberOfLectures(int x, String y)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        //SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=database;Integrated Security=True;MultipleActiveResultSets=True");
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "select ModuleId, RoomId from Lecture where SemesterId = @SemesterId and ModuleId like @ModuleId + '%'";
        //string sql = "select ModuleId from Lecture";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@SemesterId", x);
        cmd.Parameters.AddWithValue("@ModuleId", y);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {

            lectures.Add(dr["ModuleId"].ToString());
            if (!dr.IsDBNull(dr.GetOrdinal("RoomId")))
            {
                room = dr["RoomId"].ToString();
            }
            else
            {
                room = "null";
            }
            
        }
        dr.Close();
        conn.Close();
    }

    //Reads all data for a particular module for a certain year in a certain semester
    public void readYear(int x, String y, int z)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        //SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=database;Integrated Security=True;MultipleActiveResultSets=True");
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "With test as (select ModuleId, RoomId, StaffId, Day, Time, ROW_NUMBER() over (order by ModuleID) as rowNumber from Lecture where SemesterId = @SemesterId and ModuleId like @ModuleId + '%')select ModuleId, RoomId, Day, Time, rowNumber from test where rowNumber > @RowNumber";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@SemesterId", x);
        cmd.Parameters.AddWithValue("@ModuleId", y);
        cmd.Parameters.AddWithValue("@RowNumber", z);
        SqlDataReader dr = cmd.ExecuteReader();
        // int i = 0;
        while (dr.Read())
        {
            module = dr["ModuleId"].ToString();
            //moduleID.Add(dr["ModuleID"].ToString());
            if (!dr.IsDBNull(dr.GetOrdinal("RoomId")))
            {
                room = dr["RoomId"].ToString();
            }
            else
            {
                room = "null";
            }
            //day.Add(Convert.ToInt32(dr["Day"]));
            if (!dr.IsDBNull(dr.GetOrdinal("Day")))
            {
                day = dr["Day"].ToString().Trim();
            }
            else
            {
                day = "0";
            }

            if (!dr.IsDBNull(dr.GetOrdinal("Time")))
            {
                time = dr["Time"].ToString().Trim();
            }
            else
            {
                time = "0";
            }
            //i++;
            break;

        }
        dr.Close();
        conn.Close();
    }

    //Saves a lecture for a particular year
    public void writeLecture(String module, String week, String day, String time, int semester)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "select ModuleId, Day, Time, SemesterId from Lecture where ModuleId = '" + module + "' and Day = '" + day + "' and Time = '" + time + "' and SemesterId = '" + semester + "'";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlCommand cmd2 = new SqlCommand("Insert into Lecture (ModuleId, SemesterId, Week, Day, Time) values(@ModuleId, @SemesterId, @Week, @Day, @Time)", conn);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.HasRows) 
        {           
        }
        else
        {
            using (cmd2)
            {
                cmd2.Parameters.AddWithValue("@ModuleId", module);
                cmd2.Parameters.AddWithValue("@SemesterId", semester);
                cmd2.Parameters.AddWithValue("@Week", week);
                cmd2.Parameters.AddWithValue("@Day", day);
                cmd2.Parameters.AddWithValue("@Time", time);

                cmd2.ExecuteNonQuery();
            }
        }
        dr.Close();
        conn.Close();
    }

    public void deleteLecture(String day, String time, int semester)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();
        SqlCommand cmd = new SqlCommand("Delete from Lecture where Day = @day and Time = @time and SemesterId = @SemesterId", conn);
        cmd.Parameters.AddWithValue("@day", day);
        cmd.Parameters.AddWithValue("@time", time);
        cmd.Parameters.AddWithValue("@SemesterId", semester);
        cmd.ExecuteNonQuery();
        conn.Close();
    }

    public void deleteLecture2(String module, String day, String time, int semester)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();
        SqlCommand cmd = new SqlCommand("Delete from Lecture where ModuleId = @ModuleId and Day = @day and Time = @time and SemesterId = @SemesterId", conn);
        cmd.Parameters.AddWithValue("@day", day);
        cmd.Parameters.AddWithValue("@time", time);
        cmd.Parameters.AddWithValue("@SemesterId", semester);
        cmd.Parameters.AddWithValue("@ModuleId", module);
        cmd.ExecuteNonQuery();
        conn.Close();
    }

    public void updateLecture(String day, String time, int semester, String module)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();
        SqlCommand cmd = new SqlCommand("Delete from Lecture where Day = @day and Time = @time and SemesterId = @SemesterId", conn);
        cmd.Parameters.AddWithValue("@day", day);
        cmd.Parameters.AddWithValue("@time", time);
        cmd.Parameters.AddWithValue("@SemesterId", semester);
        SqlCommand cmd2 = new SqlCommand("Update Lecture set ModuleId = @ModuleId where Day = @day and Time= @time and Semester = @SemesterId");
        cmd2.Parameters.AddWithValue("@day", day);
        cmd2.Parameters.AddWithValue("@time", time);
        cmd2.Parameters.AddWithValue("@SemesterId", semester);
        cmd2.Parameters.AddWithValue("@ModuleId", module);
        cmd.ExecuteNonQuery();
        conn.Close();
    }

    public void updateLecture2(String module, String day, String time, int semester)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();
        SqlCommand cmd = new SqlCommand("Update Lecture set Day = null where ModuleId = @ModuleId and Day = @day and Time= @time and SemesterId = SemesterId", conn);
        cmd.Parameters.AddWithValue("@day", day);
        cmd.Parameters.AddWithValue("@time", time);
        cmd.Parameters.AddWithValue("@SemesterId", semester);
        cmd.Parameters.AddWithValue("@ModuleId", module);
        cmd.ExecuteNonQuery();
        conn.Close();
    }

    //Selects the year based on the module passed in
    public void readYears(String y)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        //SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=database;Integrated Security=True;MultipleActiveResultSets=True");
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "select Year from Module where ModuleId = @ModuleId";
        //string sql = "select ModuleId from Lecture";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@ModuleId", y);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {

            yearId = dr["Year"].ToString();
        }
        dr.Close();
        conn.Close();
    }

    //Reads list of unscheduled lectures
    public void readYearNull()
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select LectureId from Lecture where Day is null or Time is null or SemesterId is null or Week is null";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            LectureID.Add(dr["LectureId"].ToString());
        }
        dr.Close();
        conn.Close();
    }

    //Selects moduleId day, time, week and semester of a particular lecture
    public void readYearFinal2(String LectureId)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select ModuleId, SemesterId, Day, Time, Week from Lecture where LectureId = @LectureId";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@LectureId", LectureId);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            module = dr["ModuleId"].ToString();
            if (!dr.IsDBNull(dr.GetOrdinal("Day")))
            {
                day = dr["Day"].ToString().Trim();
            }
            else
            {
                day = "0";
            }

            if (!dr.IsDBNull(dr.GetOrdinal("Time")))
            {
                time = dr["Time"].ToString().Trim();
            }
            else
            {
                time = "0";
            }

            if (!dr.IsDBNull(dr.GetOrdinal("SemesterId")))
            {
                semester = Convert.ToInt32(dr["SemesterId"]);
            }
            else
            {
                semester = 0;
            }

            if (!dr.IsDBNull(dr.GetOrdinal("Week")))
            {
                week = dr["Week"].ToString().Trim();
            }
            else
            {
                week = "0";
            }
        }
        dr.Close();
        conn.Close();
    }

    //Deletes a particular lecture
    public void deleteModuleLectureId(String LectureId)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();
        SqlCommand cmd = new SqlCommand("Update Lecture set RoomId = null where LectureId = @LectureId", conn);
        cmd.Parameters.AddWithValue("@LectureId", LectureId);
        cmd.ExecuteNonQuery();
        conn.Close();
    }

    //Reads the year of a particular module
    public void readYearFromModule(String ModuleId)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select Year from Module where ModuleId like @ModuleId + '%'";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@ModuleId", ModuleId);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            yearId = dr["Year"].ToString();
           
        }
        dr.Close();
        conn.Close();
    }

    //Schedules a lecture
    public void writeLectureNull(String lectureId, String week, String day, String time, int semester)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();
        SqlCommand cmd2 = new SqlCommand("Update Lecture set SemesterId = @SemesterId, Week = @week, Day = @day, Time = @time where LectureId = @LectureId", conn);

        cmd2.Parameters.AddWithValue("@day", day);
        cmd2.Parameters.AddWithValue("@time", time);
        cmd2.Parameters.AddWithValue("@SemesterId", semester);
        cmd2.Parameters.AddWithValue("@LectureId", lectureId);
        cmd2.Parameters.AddWithValue("@week", week);

        cmd2.ExecuteNonQuery();
        
        conn.Close();
    }

    //Deletes a lecture from the Lecture table
    public void deleteEntry(String LectureId)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();
        SqlCommand cmd = new SqlCommand("Delete from Lecture where LectureId = @LectureId", conn);
        cmd.Parameters.AddWithValue("@LectureId", LectureId);
        cmd.ExecuteNonQuery();
        conn.Close();
    }

    //Reads all years from the Year table
    public void readYearFromYearTable()
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select YearId from Year";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            yearIdList.Add(dr["YearId"].ToString());

        }
        dr.Close();
        conn.Close();
    }

    //Getters and Setters

    public void setModuleID(int i, String x)
    {
        moduleID[i] = x;
    }

    public String getModuleID(int i)
    {
        return moduleID[i];
    }

    public String getModule()
    {
        return module;
    }

    public String getRoom()
    {
        return room;
    }

    public int getSemester()
    {
        return semester;
    }

    public String getDay()
    {
        return day;
    }

    public String getTime()
    {
        return time;
    }

    public int getModuleCount()
    {
        return moduleID.Count();
    }

    public int getLectureCount()
    {
        return lectures.Count();
    }

    public String getYear()
    {
        return yearId;
    }

    public int countLectureIdList()
    {
        return LectureID.Count();
    }

    public String getLectureIdList(int i)
    {
        return LectureID[i];
    }

    public int countYearIdList()
    {
        return yearIdList.Count;
    }

    public String getYearIdList(int i)
    {
        return yearIdList[i];
    }

    public String getWeek()
    {
        return week;
    }

}