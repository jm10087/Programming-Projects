﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Data.SqlClient;
using System.Data;

/// <summary>
/// Summary description for Class1
/// </summary>
public class Module
{

    String moduleID;
    int semester;
    List<String> modulesOfYear = new List<String>();
    List<String> modulesOfSemester = new List<String>();

    public Module()
    {

    }

    public void write()
    {
        SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=database;
Integrated Security=True;MultipleActiveResultSets=True");
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "INSERT Module (ModuleID, YearID) VALUES('BIS1', 'BIS2')";
        cmd.Connection = conn;
        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();
    }

    public void readYearTable(String x)
    {
        SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=database;Integrated Security=True;MultipleActiveResultSets=True");
        string sql = "select ModuleID from Module where YearID =" + x;
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader dr = cmd.ExecuteReader();
        int i = 0;
        while (dr.Read())
        {
            modulesOfYear[i] = dr["ModuleID"].ToString();
            i++;
        }
    }

    public void readSemesterTable(int x, String y)
    {
        SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=database;Integrated Security=True;MultipleActiveResultSets=True");
        string sql = "select ModuleID from Lecture where SemesterID = " + x + "and ModuleID = " + y;
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader dr = cmd.ExecuteReader();
        int i = 0;
        while (dr.Read())
        {
            modulesOfSemester[i] = dr["ModuleID"].ToString();
            i++;
        }
    }

    public void readSemester()
    {
        foreach (String module in modulesOfYear)
        {
            readSemesterTable(semester, module);
        }
    }



}