﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Lecture
/// </summary>
public class Lecture
{

    String lectureID;
    String uniqueStaffID;
    List<String> moduleID = new List<String>();
    List<String> staffID = new List<String>();
    List<String> roomID = new List<String>();
    List<Int32> day = new List<Int32>();
    List<Int32> time = new List<Int32>();
    int semester;



    public Lecture()
    {

    }

    public void setLectureID(String x)
    {
        lectureID = x;
    }

    public String getLectureID()
    {
        return lectureID;
    }

    public void setModuleID(int i, String x)
    {
        moduleID[i] = x;
    }

    public String getModuleID(int i)
    {
        return moduleID[i];
    }

    public void setRoomID(int i, String x)
    {
        roomID[i] = x;
    }

    public String getRoomID(int i)
    {
        return roomID[i];
    }

    public void setDay(int i, int x)
    {
        day[i] = x;
    }

    public int getDay(int i)
    {
        return day[i];
    }

    public void setTime(int i, int x)
    {
        time[i] = x;
    }

    public int getTime(int i)
    {
        return time[i];
    }

    public void setSemester(int x)
    {
        semester = x;
    }

    public int getSemester()
    {
        return semester;
    }

}