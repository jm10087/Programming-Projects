﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Data.SqlClient;
using System.Web.Configuration;

/// <summary>
/// Summary description for Lecturer
/// </summary>
public class Lecturer
{

    String staffID;
    List<String> StaffID = new List<string>();
    List<String> moduleID = new List<String>();
    List<String> moduleIDNew = new List<String>();
    List<String> roomID = new List<String>();
    List<String> day1 = new List<String>(); 
    List<String> time1 = new List<String>();
    List<String> LectureID = new List<string>();
    List<String> StaffIdList = new List<string>();
    List<String> StaffIdList2 = new List<string>();
    String module;
    String room;
    int Semester;
    String day;
    String time;
    String lectureId;
    String yearId;
    String week;
   
    public Lecturer()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    //Reads the amount of lectures associated with one lecturer in one semester
    public void readLecturerTest(int x, String y)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        //SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=database;Integrated Security=True;MultipleActiveResultSets=True");
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "select ModuleId from Lecture where SemesterId = @SemesterId and StaffId = @StaffId";
        //string sql = "select ModuleId from Lecture";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@SemesterId", x);
        cmd.Parameters.AddWithValue("@StaffId", y);
       
            

            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {

                moduleID.Add(dr["ModuleId"].ToString());
            }
            dr.Close();
        conn.Close();
    }

    //Reads lectures associated with one lecturer incrementally
    public void readLecturer(int x, String y, int z)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        //SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=database;Integrated Security=True;MultipleActiveResultSets=True");
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "With test as (select ModuleId, RoomId, Day, Time, ROW_NUMBER() over (order by ModuleID) as rowNumber from Lecture where SemesterId = @SemesterId and StaffId = @StaffId)select ModuleId, RoomId, Day, Time, rowNumber from test where rowNumber > @RowNumber";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@SemesterId", x);
        cmd.Parameters.AddWithValue("@StaffId", y);
        cmd.Parameters.AddWithValue("@RowNumber", z);
        SqlDataReader dr = cmd.ExecuteReader();
        // int i = 0;
        while (dr.Read())
        {
            module = dr["ModuleId"].ToString().Trim();
            //moduleID.Add(dr["ModuleID"].ToString());
            if (!dr.IsDBNull(dr.GetOrdinal("RoomId")))
            {
                room = dr["RoomId"].ToString();
            }
            else
            {
                room = "null";
            }
            
            //day.Add(Convert.ToInt32(dr["Day"]));
            if (!dr.IsDBNull(dr.GetOrdinal("Day")))
            {
                day = dr["Day"].ToString().Trim();
            }
            else
            {
                day = "0";
            }

            if (!dr.IsDBNull(dr.GetOrdinal("Time")))
            {
                time = dr["Time"].ToString().Trim();
            }
            else
            {
                time = "0";
            }
            //i++;
            break;

        }
        dr.Close();
        conn.Close();
    }

    public void test()
    {
        SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=database;Integrated Security=True;MultipleActiveResultSets=True");
        string sql = "select ModuleId from Lecture where ModuleId = IS4401";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader dr = cmd.ExecuteReader();
        // int i = 0;
        while (dr.Read())
        {
            module = dr["ModuleId"].ToString();
            //moduleID.Add(dr["ModuleID"].ToString());
            if (!dr.IsDBNull(dr.GetOrdinal("RoomId")))
            {
                room = dr["RoomId"].ToString();
            }
            else
            {
                room = "null";
            }

            //day.Add(Convert.ToInt32(dr["Day"]));
            if (!dr.IsDBNull(dr.GetOrdinal("Day")))
            {
                day = dr["Day"].ToString();
            }
            else
            {
                day = "0";
            }

            if (!dr.IsDBNull(dr.GetOrdinal("Time")))
            {
                time = dr["Time"].ToString();
            }
            else
            {
                time = "0";
            }
            break;

        }
        dr.Close();
        conn.Close();
    }

    //Reads all module ids from the Module table
    public void readModules()
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        //SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=database;Integrated Security=True;MultipleActiveResultSets=True");
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "select ModuleId from Module";
        //string sql = "select ModuleId from Lecture";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {

            moduleIDNew.Add(dr["ModuleId"].ToString());
            module = dr["ModuleId"].ToString();
        }
        dr.Close();
        conn.Close();
    }

    //This writes a new lecture assigned to a particular lecturer
    public void writeLecture(String module, String lecturerId)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Insert into Lecture (ModuleId, StaffId) values(@ModuleId, @LecturerId)";
        //string sql2 = "select ModuleId from Lecture where ModuleId = '" + module + "'and StaffId = '" + lecturerId + "'";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        //SqlCommand cmd2 = new SqlCommand(sql2, conn);

        cmd.Parameters.AddWithValue("@ModuleId", module);
        cmd.Parameters.AddWithValue("@LecturerId", lecturerId);

        //SqlDataReader dr = cmd2.ExecuteReader ();

        //if (dr.HasRows)
        //{

        //}
        //else
        //{

        //}
        

        cmd.ExecuteNonQuery();
        conn.Close();
    }

    //This deletes a particular lecture
    public void deleteModule(String moduleId, String lecturerId, int semester, String day, String time)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();
        SqlCommand cmd = new SqlCommand("Update Lecture set StaffId = null where ModuleId = @ModuleId and StaffId = @StaffId and SemesterId = @SemesterId and Day = @Day and time = @Time", conn);
        cmd.Parameters.AddWithValue("@ModuleId", moduleId);
        cmd.Parameters.AddWithValue("@StaffId", lecturerId);
        cmd.Parameters.AddWithValue("@SemesterId", semester);
        cmd.Parameters.AddWithValue("@Day", day);
        cmd.Parameters.AddWithValue("@Time", time);
        cmd.ExecuteNonQuery();
        conn.Close();
    }

    //Selects all lectures belonging to a particular lecturer, regardless of semester
    public void readLecturerTestSave(String y)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        //SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=database;Integrated Security=True;MultipleActiveResultSets=True");
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "select ModuleId from Lecture where StaffId = @StaffId";
        //string sql = "select ModuleId from Lecture";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@StaffId", y);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {

            moduleID.Add(dr["ModuleId"].ToString());
        }
        dr.Close();
        conn.Close();
    }

    //Reads data pertaining to a specified lecture of a lecturer
    public void readLecturerSave(String y, int z)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        //SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=database;Integrated Security=True;MultipleActiveResultSets=True");
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "With test as (select LectureId, ModuleId, RoomId, SemesterId, Week, Day, Time, ROW_NUMBER() over (order by ModuleID) as rowNumber from Lecture where StaffId = @StaffId)select LectureId, ModuleId, RoomId, SemesterId, Week, Day, Time, rowNumber from test where rowNumber > @RowNumber";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@StaffId", y);
        cmd.Parameters.AddWithValue("@RowNumber", z);
        SqlDataReader dr = cmd.ExecuteReader();
        // int i = 0;
        while (dr.Read())
        {
            lectureId = dr["LectureId"].ToString();
            module = dr["ModuleId"].ToString();
            //moduleID.Add(dr["ModuleID"].ToString());
            if (!dr.IsDBNull(dr.GetOrdinal("RoomId")))
            {
                room  = dr["RoomId"].ToString();
            }
            else
            {
                room = "null";
            }
            //day.Add(Convert.ToInt32(dr["Day"]));
            if (!dr.IsDBNull(dr.GetOrdinal("Day")))
            {
                day = dr["Day"].ToString();
            }
            else
            {
                day = "0";
            }

            if (!dr.IsDBNull(dr.GetOrdinal("Week")))
            {
                week = dr["Week"].ToString();
            }
            else
            {
                week = "0";
            }

            if (!dr.IsDBNull(dr.GetOrdinal("Time")))
            {
                time = dr["Time"].ToString();
            }
            else
            {
                time = "0";
            }

            if (!dr.IsDBNull(dr.GetOrdinal("SemesterId")))
            {
                Semester = Convert.ToInt32(dr["SemesterId"]);
            }
            else
            {
                Semester = 0;
            }
            //i++;
            break;

        }
        dr.Close();
        conn.Close();
    }

    //Selects all lectures of the selected lecturer and checks for clashes
    public void readLecturerCompare(String Lecturer)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select LectureId, SemesterId, Day, Time from Lecture where StaffId = @StaffId";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@StaffId", Lecturer);
        SqlDataReader dr = cmd.ExecuteReader();
        staffID = Lecturer;
        String LectureId;
        while (dr.Read())
        {
            LectureId = dr["LectureId"].ToString();

            if (!dr.IsDBNull(dr.GetOrdinal("Day")))
            {
                day = dr["Day"].ToString();
            }
            else
            {
                day = "0";
            }

            if (!dr.IsDBNull(dr.GetOrdinal("Time")))
            {
                time = dr["Time"].ToString();
            }
            else
            {
                time = "0";
            }

            if (!dr.IsDBNull(dr.GetOrdinal("SemesterId")))
            {
                Semester = Convert.ToInt32(dr["SemesterId"]);
            }
            else
            {
                Semester = 0;
            }
            
            readLecturerCompare2(Lecturer, day, time, Semester, LectureId);
        }
        dr.Close();
        conn.Close();
    }

    //Checks for clashes and adds the lecture ids of those lectures that are clashing
     public void readLecturerCompare2(String Lecturer, String day, String time, int semester, String lectureId)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select SemesterId, Day, Time from Lecture where StaffId = @StaffId and Day = @day and Time = @time and SemesterId = @semester and LectureId != @lectureId";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@StaffId", Lecturer);
        cmd.Parameters.AddWithValue("@day", day);
        cmd.Parameters.AddWithValue("@time", time);
        cmd.Parameters.AddWithValue("@semester", semester);
        cmd.Parameters.AddWithValue("@lectureId", lectureId);
        SqlDataReader dr = cmd.ExecuteReader();
        staffID = Lecturer;
         if (dr.HasRows)
         {
             LectureID.Add(lectureId);
         }
         dr.Close();
         conn.Close();
     }

    //Reads all lectures to see if they are clashing
     public void readLecturerMenu()
     {
         String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
         SqlConnection conn = new SqlConnection(connectionString);
         string sql = "Select LectureId, StaffId, SemesterId, Day, Time from Lecture where len(StaffId) > 1";
         conn.Open();
         SqlCommand cmd = new SqlCommand(sql, conn);
         SqlDataReader dr = cmd.ExecuteReader();
         String LectureId;
         while (dr.Read())
         {
             if (!dr.IsDBNull(dr.GetOrdinal("StaffId")))
             {
                 staffID = dr["StaffId"].ToString();
             }
             else
             {
                 staffID = "null";
             }

             LectureId = dr["LectureId"].ToString();
             if (!dr.IsDBNull(dr.GetOrdinal("Day")))
             {
                 day = dr["Day"].ToString();
             }
             else
             {
                 day = "0";
             }

             if (!dr.IsDBNull(dr.GetOrdinal("Time")))
             {
                 time = dr["Time"].ToString();
             }
             else
             {
                 time = "0";
             }

             if (!dr.IsDBNull(dr.GetOrdinal("SemesterId")))
             {
                 Semester = Convert.ToInt32(dr["SemesterId"]);
             }
             else
             {
                 Semester = 0;
             }

             if (staffID != "null")
             {


                 if (!StaffIdList.Contains(staffID)) //Ensures that lecturers don't get added twice
                 {
                     //RoomIdList2.Add(roomID);
                     int i = readLecturerMenu2(staffID, day, time, Semester, LectureId);
                     //Adds to list if clashes exist
                     if (i == 1)
                     {
                         StaffIdList.Add(staffID);
                     }
                 }
             }
         }
         dr.Close();
         conn.Close();
     }

    //Checks for clashes in lecturer timetable
     public int readLecturerMenu2(String Lecturer, String day, String time, int semester, String lectureId)
     {
         String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
         SqlConnection conn = new SqlConnection(connectionString);
         string sql = "Select SemesterId, Day, Time from Lecture where StaffId = @StaffId and Day = @day and Time = @time and SemesterId = @semester and LectureId != @lectureId";
         conn.Open();
         SqlCommand cmd = new SqlCommand(sql, conn);
         cmd.Parameters.AddWithValue("@StaffId", Lecturer);
         cmd.Parameters.AddWithValue("@day", day);
         cmd.Parameters.AddWithValue("@time", time);
         cmd.Parameters.AddWithValue("@semester", semester);
         cmd.Parameters.AddWithValue("@lectureId", lectureId);
         SqlDataReader dr = cmd.ExecuteReader();
         staffID = Lecturer;
         if (dr.HasRows)
         {
             dr.Close();
             conn.Close();
             return 1;
         }
         else
         {
             dr.Close();
             conn.Close();
             return 0;
         }
         
     }

    //Reads lecture of a lecturer at a particular time
     public void readLecturerFinal(String Lecturer, int semester, String day, String time)
     {
         String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
         SqlConnection conn = new SqlConnection(connectionString);
         string sql = "Select LectureId from Lecture where StaffId = @StaffId and SemesterId = @semester and Day = @day and Time = @time";
         conn.Open();
         SqlCommand cmd = new SqlCommand(sql, conn);
         cmd.Parameters.AddWithValue("@StaffId", Lecturer);
         cmd.Parameters.AddWithValue("@day", day);
         cmd.Parameters.AddWithValue("@time", time);
         cmd.Parameters.AddWithValue("@semester", semester);
         SqlDataReader dr = cmd.ExecuteReader();
         while (dr.Read())
         {
             LectureID.Add(dr["LectureId"].ToString());
         }
         dr.Close();
         conn.Close();
     }

     public void readLecturerModules(String lecture)
     {
         String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
         SqlConnection conn = new SqlConnection(connectionString);
         string sql = "Select SemesterId, Day, Time from Lecture where LectureId = @lectureId";
         conn.Open();
         SqlCommand cmd = new SqlCommand(sql, conn);
         cmd.Parameters.AddWithValue("@lectureId", lecture);
         SqlDataReader dr = cmd.ExecuteReader();
         while (dr.Read())
         {
             if (!dr.IsDBNull(dr.GetOrdinal("Day")))
             {
                 day = dr["Day"].ToString();
             }
             else
             {
                 day = "0";
             }

             if (!dr.IsDBNull(dr.GetOrdinal("Time")))
             {
                 time = dr["Time"].ToString();
             }
             else
             {
                 time = "0";
             }

             if (!dr.IsDBNull(dr.GetOrdinal("SemesterId")))
             {
                 Semester = Convert.ToInt32(dr["SemesterId"]);
             }
             else
             {
                 Semester = 0;
             }
         }
         dr.Close();
         conn.Close();
     }

    //Selects moduleId day, time, week and semester of a particular lecture
     public void readLecturerFinal2(String LectureId)
     {
         String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
         SqlConnection conn = new SqlConnection(connectionString);
         string sql = "Select ModuleId, SemesterId, Day, Time, Week from Lecture where LectureId = @lectureId";
         conn.Open();
         SqlCommand cmd = new SqlCommand(sql, conn);
         cmd.Parameters.AddWithValue("@lectureId", LectureId);
         SqlDataReader dr = cmd.ExecuteReader();
         while (dr.Read())
         {
             module = dr["ModuleId"].ToString();
             if (!dr.IsDBNull(dr.GetOrdinal("Day")))
             {
                 day = dr["Day"].ToString();
             }
             else
             {
                 day = "0";
             }

             if (!dr.IsDBNull(dr.GetOrdinal("Time")))
             {
                 time = dr["Time"].ToString();
             }
             else
             {
                 time = "0";
             }

             if (!dr.IsDBNull(dr.GetOrdinal("SemesterId")))
             {
                 Semester = Convert.ToInt32(dr["SemesterId"]);
             }
             else
             {
                 Semester = 0;
             }

             if (!dr.IsDBNull(dr.GetOrdinal("Week")))
             {
                 week = dr["Week"].ToString().Trim();
             }
             else
             {
                 week = "0";
             }
         }
         dr.Close();
         conn.Close();
     }

    //Removes a particular lecture from its lecturer's schedule
    public void deleteModuleClash(String lectureId)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();
        SqlCommand cmd = new SqlCommand("Update Lecture set StaffId = null where LectureId = @lectureId", conn);
        cmd.Parameters.AddWithValue("@lectureId", lectureId);
        cmd.ExecuteNonQuery();
        conn.Close();
    }

    //Reads lectures where StaffId is null or blank
    public void readLecturerNull()
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select LectureId, ModuleId, SemesterId, Day, Time from Lecture where StaffId is null or StaffId = ''";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            LectureID.Add(dr["LectureId"].ToString());
        }
        dr.Close();
        conn.Close();
    }

    //Deletes a particular lecture
    public void deleteModuleLectureId(String lectureId)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();
        SqlCommand cmd = new SqlCommand("Update Lecture set StaffId = null where LectureId = @lectureId", conn);
        cmd.Parameters.AddWithValue("@lectureId", lectureId);
        cmd.ExecuteNonQuery();
        conn.Close();
    }

    public void readLecturerById(int x, String y)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        //SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=database;Integrated Security=True;MultipleActiveResultSets=True");
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "select ModuleId from Lecture where StaffId = @lectureId";
        //string sql = "select ModuleId from Lecture";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@lectureId", y);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {

            moduleID.Add(dr["ModuleId"].ToString());
        }
        dr.Close();
        conn.Close();
    }

    //Reads all StaffIds in the Lecturer table
    public void readFromLecturerTable()
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "select StaffId from Lecturer";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader dr = cmd.ExecuteReader();
        StaffID.Clear();
        while (dr.Read())
        {

            StaffID.Add(dr["StaffId"].ToString());
        }
        dr.Close();
        conn.Close();
    }

    //Sets a StaffId to an unassigned lecture
    public void writeLectureById(String lecture, String lecturerId)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Update Lecture set StaffId = @LecturerId where LectureId = @Lecture";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@Lecture", lecture);
        cmd.Parameters.AddWithValue("@LecturerId", lecturerId);

        cmd.ExecuteNonQuery();
        conn.Close();
    }

    //Reads the year of a particular module
    public void readYearFromModule(String ModuleId)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select Year from Module where ModuleId = @ModuleId";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@ModuleId", ModuleId);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            yearId = dr["Year"].ToString();

        }
        dr.Close();
        conn.Close();
    }

    //Deletes a lecture from the Lecture table
    public void deleteEntry(String LectureId)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        conn.Open();
        SqlCommand cmd = new SqlCommand("Delete from Lecture where LectureId = @lectureId", conn);
        cmd.Parameters.AddWithValue("@lectureId", LectureId);
        cmd.ExecuteNonQuery();
        conn.Close();
    }

    //Getters and Setters

    public void setModuleID(int i, String x)
    {
        moduleID[i] = x;
    }

    public String getModuleID(int i)
    {
        return moduleID[i];
    }

    public void setRoomID(int i, String x)
    {
        roomID[i] = x;
    }

    public String getRoomID(int i)
    {
        return roomID[i];
    }

    public void setDay1(int i, String x)
    {
        day1[i] = x;
    }

    public String getDay1(int i)
    {
        return day1[i];
    }

    public void setTime1(int i, String x)
    {
        time1[i] = x;
    }

    public String getTime1(int i)
    {
        return time1[i];
    }


    public String getModule()
    {
        return module;
    }

    public String getRoom()
    {
        return room;
    }

    public String getDay()
    {
        return day;
    }

    public String getTime()
    {
        return time;
    }

    public int getModuleCount()
    {
        return moduleID.Count();
    }

    public int getModuleNewCount()
    {
        return moduleIDNew.Count();
    }

    public String getModuleIDNew(int i)
    {
        return moduleIDNew[i];
    }

    public int getSemester()
    {
        return Semester;
    }

    public int countStaffIdList()
    {
        return StaffIdList.Count();
    }

    public String getStaffIdList(int i)
    {
        return StaffIdList[i];
    }

    public int countLectureIdList()
    {
        return LectureID.Count();
    }

    public String getLectureIdList(int i)
    {
        return LectureID[i];
    }

    public String getLectureId()
    {
        return lectureId;
    }

    public int getStaffIdCount()
    {
        return StaffID.Count();
    }

    public String getLecturerIdList(int i)
    {
        return StaffID[i];
    }

    public String getYear()
    {
        return yearId;
    }

    public String getWeek()
    {
        return week;
    }

}