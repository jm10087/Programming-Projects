﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class test : System.Web.UI.Page
{

    List<String> s = new List<string>();

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    //Uploads data from Excel
    protected void Button1_Click(object sender, EventArgs e)
    {
        //Upload and save the file
        //string excelPath = Server.MapPath("~/Files/") + Path.GetFileName(FileUpload1.PostedFile.FileName);
        string excelPath = Server.MapPath("~/") + Path.GetFileName(FileUpload1.PostedFile.FileName);
        FileUpload1.SaveAs(excelPath);

        string conString = string.Empty;
        string extension = Path.GetExtension(FileUpload1.PostedFile.FileName);
        switch (extension)
        {
            case ".xls": //Excel 97-03
                conString = ConfigurationManager.ConnectionStrings["Excel03ConString"].ConnectionString;
                break;
            case ".xlsx": //Excel 07 or higher
                conString = ConfigurationManager.ConnectionStrings["Excel07+ConString"].ConnectionString;
                break;

        }

        deleteData();

        conString = string.Format(conString, excelPath);
        using (OleDbConnection excel_con = new OleDbConnection(conString))
        {
            excel_con.Open();
            string sheet1 = excel_con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null).Rows[0]["TABLE_NAME"].ToString();
            DataTable dtExcelData = new DataTable();

            //[OPTIONAL]: It is recommended as otherwise the data will be considered as String by default.
            dtExcelData.Columns.AddRange(new DataColumn[7] { new DataColumn("Module", typeof(string)),
                new DataColumn("Weeks", typeof(string)),
                new DataColumn("Day",typeof(string)),
                new DataColumn("Start",typeof(string)),
                new DataColumn("Finish",typeof(string)),
                new DataColumn("RoomId",typeof(string)),
                new DataColumn("StaffId",typeof(string))});

            using (OleDbDataAdapter oda = new OleDbDataAdapter("SELECT * FROM [" + sheet1 + "]", excel_con))
            {
                oda.Fill(dtExcelData);
            }
            excel_con.Close();

            string consString = ConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
            using (SqlConnection con = new SqlConnection(consString))
            {
                using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(con))
                {
                    //Set the database table name
                    sqlBulkCopy.DestinationTableName = "Lecture";

                    //[OPTIONAL]: Map the Excel columns with that of the database table
                    sqlBulkCopy.ColumnMappings.Add("Name", "ModuleId");//Name
                    sqlBulkCopy.ColumnMappings.Add("Weeks", "Week");//Weeks
                    sqlBulkCopy.ColumnMappings.Add("Day", "Day");//Day
                    sqlBulkCopy.ColumnMappings.Add("Start", "StartTime2");//Start
                    sqlBulkCopy.ColumnMappings.Add("Finish", "EndTime2");//Finish
                    sqlBulkCopy.ColumnMappings.Add("Location", "RoomId");//Location
                    sqlBulkCopy.ColumnMappings.Add("Staff", "StaffId");//Staff
                    con.Open();
                    sqlBulkCopy.WriteToServer(dtExcelData);
                    con.Close();
                }
            }
        }

        //Converts data to format for use in database
        deleteNulls();
        assignSemester();
        setTimes();
        splitIntoHours();
        populateModules();
        populateLecturer();
        populateRoom();
    }

    //This assigns semesters to the modules, which are not specified in the Excel sheets
    protected void assignSemester()
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select LectureId, Week from Lecture where ModuleId is not null";
        conn.Open();
        string sql2;
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlCommand cmd2;
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            String week = dr["Week"].ToString().Trim();
            String LectureId = dr["LectureId"].ToString().Trim();
            if (week == "5-16") //Semester 1
            {
                sql2 = "Update Lecture set SemesterId = 1 where LectureId='" + LectureId + "'";
                cmd2 = new SqlCommand(sql2, conn);
                cmd2.ExecuteNonQuery();
            }
            else if (week == "23-34") //Semester 2
            {
                sql2 = "Update Lecture set SemesterId = 2 where LectureId='" + LectureId + "'";
                cmd2 = new SqlCommand(sql2, conn);
                cmd2.ExecuteNonQuery();
            }
            else if (week == "5-16, 23-34") //Some entries have both semesters specified. These must be split into two entries
            {
                splitIntoSemesters(LectureId);
            }
            else
            {
                if (week.Contains(',')) //Commonly used to specify different weeks. e.g. 3, 5
                {
                    String weekValue = week.Substring(0, week.IndexOf(",")); //Semester comes from first week specified

                    if (weekValue.Contains('-'))
                    {
                        //Semester comes from first week specified
                        String weekValue2 = weekValue.Substring(0, week.IndexOf("-")); //Commonly used to specify different weeks. e.g. 4-7, 9-16
                        int weekValueTest = Convert.ToInt32(weekValue2);
                        if (weekValueTest < 17)
                        {
                            sql2 = "Update Lecture set SemesterId = 1 where LectureId='" + LectureId + "'";
                            cmd2 = new SqlCommand(sql2, conn);
                            cmd2.ExecuteNonQuery();
                        }
                        else
                        {
                            sql2 = "Update Lecture set SemesterId = 2 where LectureId='" + LectureId + "'";
                            cmd2 = new SqlCommand(sql2, conn);
                            cmd2.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        //Semester comes from first week specified
                        int weekValueTest = Convert.ToInt32(weekValue);

                        if (weekValueTest < 17)
                        {
                            sql2 = "Update Lecture set SemesterId = 1 where LectureId='" + LectureId + "'";
                            cmd2 = new SqlCommand(sql2, conn);
                            cmd2.ExecuteNonQuery();
                        }
                        else
                        {
                            sql2 = "Update Lecture set SemesterId = 2 where LectureId='" + LectureId + "'";
                            cmd2 = new SqlCommand(sql2, conn);
                            cmd2.ExecuteNonQuery();
                        }
                    }
                }
                else if (week.Contains('-')) //Weeks may contain '-' without a comma
                {
                    String weekValue2 = week.Substring(0, week.IndexOf("-"));
                    int weekValueTest = Convert.ToInt32(weekValue2);
                    if (weekValueTest < 17)
                    {
                        sql2 = "Update Lecture set SemesterId = 1 where LectureId='" + LectureId + "'";
                        cmd2 = new SqlCommand(sql2, conn);
                        cmd2.ExecuteNonQuery();
                    }
                    else
                    {
                        sql2 = "Update Lecture set SemesterId = 2 where LectureId='" + LectureId + "'";
                        cmd2 = new SqlCommand(sql2, conn);
                        cmd2.ExecuteNonQuery();
                    }
                }
                else
                {
                    //For lectures that take place in one week only
                    int weekValueTest = Convert.ToInt32(week);

                    if (weekValueTest < 17)
                    {
                        sql2 = "Update Lecture set SemesterId = 1 where LectureId='" + LectureId + "'";
                        cmd2 = new SqlCommand(sql2, conn);
                        cmd2.ExecuteNonQuery();
                    }
                    else
                    {
                        sql2 = "Update Lecture set SemesterId = 2 where LectureId='" + LectureId + "'";
                        cmd2 = new SqlCommand(sql2, conn);
                        cmd2.ExecuteNonQuery();
                    }
                }
            }

        }
        dr.Close();
        conn.Close();
    }

    //This splits entries that have two semesters specified into two separate entries, one for each semester
    protected void splitIntoSemesters(String lectureId)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select ModuleId, StaffId, RoomId, Day, StartTime2, EndTime2 from Lecture where LectureId = '" + lectureId + "'";
        conn.Open();
        string sql2;
        String sql3;
        String sql4;
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlCommand cmd2;
        SqlCommand cmd3;
        SqlCommand cmd4;
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            //Copy other information from the table row
            String ModuleId = dr["ModuleId"].ToString();
            String StaffId = dr["StaffId"].ToString();
            String RoomId = dr["RoomId"].ToString();
            String Day = dr["Day"].ToString();
            String StartTime = dr["StartTime2"].ToString();
            String EndTime = dr["EndTime2"].ToString();

            //Entry 1
            sql2 = "Insert into Lecture (ModuleId, StaffId, RoomId, SemesterId, Day, StartTime2, EndTime2, Week) values('" + ModuleId + "', '" + StaffId + "', '" + RoomId + "', '1', '" + Day + "', '" + StartTime + "', '" + EndTime + "', '5-16')";
            cmd2 = new SqlCommand(sql2, conn);
            cmd2.ExecuteNonQuery();

            //Entry 2
            sql4 = "Insert into Lecture (ModuleId, StaffId, RoomId, SemesterId, Day, StartTime2, EndTime2, Week) values('" + ModuleId + "', '" + StaffId + "', '" + RoomId + "', '2', '" + Day + "', '" + StartTime + "', '" + EndTime + "', '23-34')";
            cmd4 = new SqlCommand(sql4, conn);
            cmd4.ExecuteNonQuery();

            //Delete original entry
            sql3 = "Delete from Lecture where LectureId = '" + lectureId + "'";
            cmd3 = new SqlCommand(sql3, conn);
            cmd3.ExecuteNonQuery();
        }
        dr.Close();
        conn.Close();
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        //populateRoom();
        populateLecturer();
    }

    //The data structure of the system means the Time column of the Lecture table must be 'x:00 - x:00'. This method adapts the data to ensure that is the case.
    protected void setTimes()
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select LectureId, StartTime2, EndTime2 from Lecture where ModuleId is not null";
        conn.Open();
        string sql2;
        string sql3;
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlCommand cmd2;
        SqlCommand cmd3;
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            String LectureId = dr["LectureId"].ToString().Trim();
            String StartTime = dr["StartTime2"].ToString().Trim();
            String EndTime = dr["EndTime2"].ToString().Trim();

            //Data is imported as DateTime format. Data is automatically assigned a date of 30/12/1899. This must be removed. New columns are created that only contain the time.
            String newStartTime = StartTime.Split(' ')[1];
            sql2 = "Update Lecture set StartTime = '" + newStartTime + "', StartTime2 = null where LectureId='" + LectureId + "'";
            cmd2 = new SqlCommand(sql2, conn);
            cmd2.ExecuteNonQuery();

            String newEndTime = EndTime.Split(' ')[1];
            sql3 = "Update Lecture set EndTime = '" + newEndTime + "', EndTime2 = null where LectureId='" + LectureId + "'";
            cmd3 = new SqlCommand(sql3, conn);
            cmd3.ExecuteNonQuery();
        }
        dr.Close();
        conn.Close();
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        setTimes();
    }

    //Delete junk data where all information is null
    protected void deleteNulls()
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Delete from Lecture where ModuleId is null";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.ExecuteNonQuery();
        conn.Close();
    }

    //This is old code
    protected void Button4_Click(object sender, EventArgs e)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select StartTime from Lecture where LectureId = 3131";
        conn.Open();
        string sql2;
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlCommand cmd2;
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            DateTime x = new DateTime();
            x = Convert.ToDateTime(dr["StartTime"].ToString().Trim());
            Label1.Text = x.ToShortTimeString();
        }
        conn.Close();
    }

    //This completes the process of converting the time as specified in 'setTimes()' above
    protected void splitIntoHours()
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select LectureId, ModuleId, StaffId, RoomId, SemesterId, Week, Day, StartTime, EndTime from Lecture";
        conn.Open();
        string sql2;
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlCommand cmd2;
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {

            List<int> times = new List<int>();
            List<String> test = new List<string>();

            String lectureId = dr["LectureId"].ToString();
            String ModuleId = dr["ModuleId"].ToString();
            String StaffId = dr["StaffId"].ToString();
            String week = dr["Week"].ToString();
            String RoomId = dr["RoomId"].ToString();
            String SemesterId = dr["SemesterId"].ToString();
            String Day = dr["Day"].ToString();
            string time1 = dr["StartTime"].ToString();
            string time2 = dr["EndTime"].ToString();

            //System.Diagnostics.Debug.WriteLine(lectureId);

            string newTime1 = time1.Substring(0, time1.IndexOf(":")); //Gets the hour value of the lectures start time
            string newTime2 = time2.Substring(0, time2.IndexOf(":")); //Gets the hour value of the lectures end time

            int time1Int = Convert.ToInt32(newTime1);
            int time2Int = Convert.ToInt32(newTime2);

            for (int i = time1Int; i <= time2Int; i++)
            {
                times.Add(i); //Adds all times to array
            }

            //Creates new entries with times in the correct 'x:00 - x:00' format for this system
            for (int i = 0; i < times.Count() - 1; i++)
            {
                String x = times[i].ToString() + ":00-" + times[i + 1].ToString() + ":00";
                String sql4 = "Insert into Lecture (ModuleId, StaffId, RoomId, SemesterId, Day, Time, Week) values('" + ModuleId + "', '" + StaffId + "', '" + RoomId + "', '" + SemesterId + "' , '" + Day + "', '" + x + "', '" + week + "')";
                SqlCommand cmd4 = new SqlCommand(sql4, conn);
                cmd4.ExecuteNonQuery();

                //Deletes old entry
                sql2 = "Delete from Lecture where LectureId = '" + lectureId + "'";
                cmd2 = new SqlCommand(sql2, conn);
                cmd2.ExecuteNonQuery();
            }

        }
        dr.Close();
        conn.Close();
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        splitIntoHours();
    }

    //Populates the Module table based on values imported into the Lecture table from the Excel spreadsheet.
    protected void populateModules()
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select distinct ModuleId from Lecture";
        conn.Open();
        string sql2;
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlCommand cmd2;
        SqlDataReader dr = cmd.ExecuteReader();
        List<string> modules = new List<string>();
        while (dr.Read())
        {
            String moduleId = dr["ModuleId"].ToString().Trim();
            String moduleId2 = "test";

            //Modules commonly conatin excess data after a '/'
            if (moduleId.Contains("/"))
            {
                moduleId2 = moduleId.Substring(0, moduleId.IndexOf('/'));
            }
            else
            {
                moduleId2 = moduleId;
            }
            if (!modules.Contains(moduleId2.Trim()))
            {
                populateYear(moduleId2);
                modules.Add(moduleId2.Trim());
            }

        }
        dr.Close();
        conn.Close();
    }

    //Assigns Years to the imported modules.
    protected void populateYear(String moduleId)
    {
        String x = "test";

        if (moduleId.Contains("IS1"))
        {
            x = "BIS1";
        }
        else if (moduleId.Contains("IS2"))
        {
            x = "BIS2";
        }
        else if (moduleId.Contains("IS3"))
        {
            x = "BIS3";
        }
        else if (moduleId.Contains("IS4"))
        {
            x = "BIS4";
        }

        else if (moduleId.Contains("IS6"))
        {
            x = "BIS6";
        }

        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "insert into Module (ModuleId, Year) values ('" + moduleId.Trim() + "', '" + x.Trim() + "')";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.ExecuteNonQuery();
        conn.Close();
    }

    //Populates the Lecturer table based on values imported into the Lecture table from the Excel spreadsheet.
    protected void populateLecturer()
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select distinct StaffId from Lecture where StaffId is not null and len(StaffId) > 1";
        conn.Open();
        string sql2;
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlCommand cmd2;
        SqlDataReader dr = cmd.ExecuteReader();
        List<string> modules = new List<string>();
        while (dr.Read())
        {
            String staffId = dr["StaffId"].ToString().Trim();
            sql2 = "insert into Lecturer (StaffId) values ('" + staffId + "')";
            cmd2 = new SqlCommand(sql2, conn);
            cmd2.ExecuteNonQuery();
        }
        dr.Close();
        conn.Close();
    }

    //Populates the Room table based on values imported into the Lecture table from the Excel spreadsheet.
    protected void populateRoom()
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Select distinct RoomId from Lecture where RoomId is not null and len(RoomId) > 1";
        conn.Open();
        string sql2;
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlCommand cmd2;
        SqlDataReader dr = cmd.ExecuteReader();
        List<string> modules = new List<string>();
        while (dr.Read())
        {
            String roomId = dr["RoomId"].ToString().Trim();
            sql2 = "insert into Room (RoomId) values ('" + roomId + "')";
            cmd2 = new SqlCommand(sql2, conn);
            cmd2.ExecuteNonQuery();
        }
        dr.Close();
        conn.Close();
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("MainMenu.aspx");
    }

    protected void deleteData()
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["ConnectionString1"].ConnectionString;
        SqlConnection conn = new SqlConnection(connectionString);
        string sql = "Delete from Lecture";
        string sql2 = "Delete from Lecturer";
        string sql3 = "Delete from Module";
        string sql4 = "Delete from Room";
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlCommand cmd2 = new SqlCommand(sql2, conn);
        SqlCommand cmd3 = new SqlCommand(sql3, conn);
        SqlCommand cmd4 = new SqlCommand(sql4, conn);

        cmd.ExecuteNonQuery();
        cmd2.ExecuteNonQuery();
        cmd3.ExecuteNonQuery();
        cmd4.ExecuteNonQuery();
    }


}